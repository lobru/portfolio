// dashboard.jsx — main UEVR progress dashboard.
// Composes header / vitals / roadmap / kanban / deps / issues / files / scripts / side-tasks
// with a Tweaks panel for theme, density, and section visibility.

const { useEffect, useMemo, useState, useRef } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "console",
  "density": "comfortable",
  "viewMode": "recruiter",
  "showRoadmap": true,
  "showKanban": true,
  "showDeps": true,
  "showIssues": true,
  "showFiles": true,
  "showScripts": true,
  "showSideTasks": true,
  "showGallery": false,
  "kanbanGroupBy": "status"
}/*EDITMODE-END*/;

// ═════════════════════════════════════════════════════════════
// Small primitives
// ═════════════════════════════════════════════════════════════

function Pill({ kind = "tag", children }) {
  const className = "pill " + kind;
  return (
    <span className={className}>
      {kind !== "tag" && <span className="dot"></span>}
      {children}
    </span>
  );
}

function SectionHead({ num, title, aside, children }) {
  return (
    <div className="section-head">
      <span className="section-num">§ {num}</span>
      <h2 className="section-title">{title}</h2>
      <div className="section-rule"></div>
      {aside && <span className="section-aside">{aside}</span>}
      {children}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Header strip
// ═════════════════════════════════════════════════════════════

function HeaderStrip({ meta }) {
  return (
    <header className="header">
      <div className="sigil">
        <div className="sigil-mark">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
            <path d="M3 6 L13 3 L23 6 L23 18 L13 23 L3 18 Z" stroke="var(--accent)" strokeWidth="1.4" fill="none" />
            <path d="M8 9 L13 7 L18 9 L18 16 L13 19 L8 16 Z" stroke="var(--accent)" strokeWidth="1" fill="none" opacity="0.5" />
            <circle cx="13" cy="13" r="1.6" fill="var(--accent)" />
          </svg>
        </div>
        <div className="sigil-text">
          <span className="crumbs">
            <span className="live"></span>
            {meta.project} · branch · <strong style={{ color: "var(--accent)" }}>{meta.branch}</strong>
          </span>
          <h1 className="title">
            <em>luavrlib</em> · progress
          </h1>
        </div>
      </div>
      <div></div>
      <div className="header-meta">
        <span>last sync</span>
        <span className="stamp">{meta.lastUpdated}</span>
        <span>baseline · {meta.baseline}</span>
        <span>{meta.docCount} docs · {meta.repoPath}</span>
      </div>
    </header>
  );
}

// ═════════════════════════════════════════════════════════════
// Vitals
// ═════════════════════════════════════════════════════════════

function Vitals({ vitals }) {
  const tiles = [
    { num: vitals.shipped,         label: "shipped",    sub: "features + fixes landed",    cls: "shipped" },
    { num: vitals.inProgress,      label: "in progress", sub: "candidate fixes pending",   cls: "inprog" },
    { num: vitals.open,            label: "open issues", sub: "blocking multi-viewport",   cls: "open" },
    { num: vitals.scriptsAudited,  label: "scripts ok",  sub: `${vitals.scriptsRewritten} rewritten · ${vitals.scriptsNew} new`,    cls: "" },
    { num: vitals.filesTouched + 7, label: "files touched", sub: `${vitals.cppFiles}c++ · ${7}lua-api`, cls: "" },
    { num: 3,                       label: "side-tasks",  sub: "sibling repos",             cls: "" },
  ];
  return (
    <div className="vitals">
      {tiles.map((t) => (
        <div key={t.label} className={"vital " + t.cls}>
          {t.cls && <span className="vital-dot"></span>}
          <span className="vital-num">{t.num}</span>
          <span className="vital-label">{t.label}</span>
          <span className="vital-sub">{t.sub}</span>
        </div>
      ))}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Roadmap
// ═════════════════════════════════════════════════════════════

function Roadmap({ milestones }) {
  // Each tick gets a fixed 150px slot in a flex row; container scrolls horizontally.
  // Labels alternate above and below the axis to give each one breathing room.
  const N = milestones.length;
  return (
    <div className="roadmap-frame">
      <div className="panel-head">
        <span>Milestones · 2026-04 → next  ·  {N} entries</span>
        <span style={{ color: "var(--text-2)" }}>
          <Pill kind="shipped">shipped</Pill>{" "}
          <Pill kind="inprog">in progress</Pill>{" "}
          <Pill kind="open">next</Pill>
        </span>
      </div>
      <div className="roadmap-scroller">
        <div className="roadmap-axis">
          <div className="roadmap-track"></div>
          {milestones.map((m, i) => {
            const cls =
              m.kind === "ship" ? "shipped"
              : m.kind === "in-progress" ? "inprog"
              : m.kind === "audit" ? "audit"
              : "next";
            const placement = i % 2 === 0 ? "above" : "below";
            return (
              <div key={i} className={"roadmap-tick " + cls + " " + placement}>
                <span className="date">{m.date}</span>
                <span className="stem"></span>
                <span className="mark"></span>
                <span className="label">{m.label}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Kanban
// ═════════════════════════════════════════════════════════════

function Kanban({ cards, symptoms, plan, companion }) {
  const [expanded, setExpanded] = useState(null);
  const toggle = (id) => setExpanded((e) => (e === id ? null : id));

  const shipped = cards.filter((c) => c.status === "shipped");
  const inprog = cards.filter((c) => c.status === "in-progress");
  const openCards = [
    ...symptoms.map((s) => ({
      id: s.id, title: s.title, status: "open", group: "Symptom · viewport",
      tags: [s.severity === "high" ? "high-sev" : "med-sev"],
      blurb: s.detail,
    })),
    ...plan.map((p) => ({
      id: "plan-" + p.step, title: `Plan §${p.step}: ${p.title}`, status: "open",
      group: "Fix plan", tags: ["next"],
      blurb: p.detail,
      checks: p.checks,
    })),
  ];

  return (
    <div className="kanban">
      <KanbanCol title="Shipped" status="shipped" count={shipped.length}>
        {shipped.map((c) => (
          <Card key={c.id} card={c} expanded={expanded === c.id} onToggle={() => toggle(c.id)} companion={companion} />
        ))}
      </KanbanCol>
      <KanbanCol title="In Progress" status="inprog" count={inprog.length}>
        {inprog.map((c) => (
          <Card key={c.id} card={c} expanded={expanded === c.id} onToggle={() => toggle(c.id)} companion={companion} />
        ))}
      </KanbanCol>
      <KanbanCol title="Open / Next" status="open" count={openCards.length}>
        {openCards.map((c) => (
          <Card key={c.id} card={c} expanded={expanded === c.id} onToggle={() => toggle(c.id)} companion={companion} />
        ))}
      </KanbanCol>
    </div>
  );
}

function KanbanCol({ title, status, count, children }) {
  return (
    <div className={"col " + status}>
      <div className="col-head">
        <span className="col-title">
          <span className="swatch"></span>
          {title}
        </span>
        <span className="col-count">{count}</span>
      </div>
      <div className="col-body">{children}</div>
    </div>
  );
}

function Card({ card, expanded, onToggle, companion }) {
  return (
    <div className={"card " + (expanded ? "expanded" : "")} onClick={onToggle}>
      <div className="card-top">
        <span className="card-group">{card.group}</span>
        <div className="card-tags">
          {card.tags && card.tags.slice(0, 2).map((t) => <Pill key={t} kind="tag">{t}</Pill>)}
        </div>
      </div>
      <div className="card-title">{card.title}</div>
      <div className="card-blurb">{card.blurb}</div>

      {expanded && (
        <div className="card-detail" onClick={e => e.stopPropagation()}>
          {card.detail && <p>{card.detail}</p>}
          {card.fix && <p><strong style={{ color: "var(--shipped)" }}>Fix: </strong>{card.fix}</p>}

          {card.surface && (
            <div className="card-section">
              <div className="card-section-label">New surface — {card.surface.length} items</div>
              <ul className="card-list">
                {card.surface.map((s, i) => <li key={i}>{s}</li>)}
              </ul>
            </div>
          )}

          {card.newApis && (
            <div className="card-section">
              <div className="card-section-label">New / now-working bindings</div>
              <div className="card-files">
                {card.newApis.map((a) => <span key={a} className="file">{a}</span>)}
              </div>
            </div>
          )}

          {card.alsoAppliedTo && (
            <div className="card-section">
              <div className="card-section-label">Also applied to</div>
              <ul className="card-list">
                {card.alsoAppliedTo.map((s, i) => <li key={i}>{s}</li>)}
              </ul>
            </div>
          )}

          {card.targets && (
            <div className="card-section">
              <div className="card-section-label">Drop targets</div>
              <ul className="card-list">
                {card.targets.map((s, i) => <li key={i}>{s}</li>)}
              </ul>
            </div>
          )}

          {card.perfBars && (
            <div className="card-section">
              <div className="card-section-label">Synthetic benchmark (lower = faster)</div>
              <div className="perfbars">
                {card.perfBars.map((b) => (
                  <div key={b.label} className={"perfbar" + (b.baseline ? " baseline" : "")}>
                    <span className="name">{b.label}</span>
                    <span className="track"><span className="fill" style={{ width: `${b.pct}%` }}></span></span>
                    <span className="pct">{b.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {card.checks && (
            <div className="card-section">
              <div className="card-section-label">Acceptance checks</div>
              <ul className="plan-checks">
                {card.checks.map((c, i) => <li key={i}>{c}</li>)}
              </ul>
            </div>
          )}

          {card.files && (
            <div className="card-section">
              <div className="card-section-label">Files</div>
              <div className="card-files">
                {card.files.map((f) => <span key={f} className="file">{f}</span>)}
              </div>
            </div>
          )}

          {card.stats && (
            <div className="card-section">
              <div className="card-section-label">Net diff</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
                <span style={{ color: "var(--muted)" }}>{card.stats.before} lines</span>
                {" → "}
                <span style={{ color: "var(--shipped)" }}>{card.stats.after} lines</span>{" "}
                <span style={{ color: "var(--shipped)" }}>({card.stats.deltaPct}%)</span>
              </div>
            </div>
          )}

          {/* Notes area — always shown in expanded cards; AskClaude shows when companion available */}
          <NotesArea card={card} data={window.PROGRESS_DATA || window.UEVR_DATA} />
          <AskClaudeBar card={card} companion={companion} />
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Issues — symptoms + 4-step plan
// ═════════════════════════════════════════════════════════════

function Issues({ symptoms, plan }) {
  const bugs     = symptoms.filter((s) => !s.kind || s.kind === "bug");
  const features = symptoms.filter((s) => s.kind === "feature");
  return (
    <div className="issues-grid">
      <div className="panel">
        <div className="panel-head">
          <span>Open items · {bugs.length} bugs · {features.length} backlog</span>
          <span style={{ color: "var(--open)" }}>{symptoms.length} active</span>
        </div>
        <div className="panel-body" style={{ paddingTop: 6 }}>
          {symptoms.map((s) => (
            <div key={s.id} className={
              "symptom " +
              (s.kind === "feature" ? "feature-item " : "") +
              (s.severity === "medium" || s.severity === "low" ? "medium" : "")
            }>
              <div className="symptom-title">
                <span className={"symptom-sev" + (s.kind === "feature" ? " feature-sev" : "")}>
                  {s.kind === "feature" ? "backlog" : s.severity}
                </span>
                {s.title}
              </div>
              <div className="symptom-body">{s.detail}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <span>Plan to validate before re-flipping the flag</span>
          <span style={{ color: "var(--accent)" }}>4 steps</span>
        </div>
        <div>
          {plan.map((p) => (
            <div key={p.step} className="plan-step">
              <span className="plan-num">{String(p.step).padStart(2, "0")}</span>
              <div>
                <div className="plan-title">
                  {p.title}
                  <Pill kind={p.state === "done" ? "shipped" : "open"}>{p.state}</Pill>
                </div>
                <div className="plan-detail">{p.detail}</div>
                {p.checks && (
                  <CheckList
                    ownerId={`plan-${p.step}`}
                    ownerTitle={`Plan §${p.step}: ${p.title}`}
                    items={p.checks}
                  />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Files heatmap
// ═════════════════════════════════════════════════════════════

function FilesHeatmap({ files }) {
  const [openPath, setOpenPath] = useState(null);
  const sorted = [...files].sort((a, b) => b.changeCount - a.changeCount);
  const max = Math.max(...sorted.map((f) => f.changeCount));

  return (
    <div className="panel">
      <div className="panel-head">
        <span>{files.length} files · {files.reduce((s, f) => s + f.changeCount, 0)} discrete changes</span>
        <span style={{ color: "var(--muted)" }}>click to expand</span>
      </div>
      <div className="files-grid">
        {sorted.map((f) => (
          <React.Fragment key={f.path}>
            <div className={"file-row" + (openPath === f.path ? " open" : "")}
                 onClick={() => setOpenPath(openPath === f.path ? null : f.path)}
                 style={{ cursor: "pointer" }}>
              <span className={"file-domain " + f.domain}>{f.domain}</span>
              <span className="file-path">{f.path}</span>
              <span className="file-bar">
                {Array.from({ length: max }).map((_, i) => (
                  <span key={i} className="seg" style={{ opacity: i < f.changeCount ? 1 : 0.18 }}></span>
                ))}
              </span>
              <span className="file-count">{f.changeCount} change{f.changeCount !== 1 ? "s" : ""}</span>
            </div>
            {openPath === f.path && (
              <div className="file-changes">
                <ul>
                  {f.changes.map((c, i) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Scripts
// ═════════════════════════════════════════════════════════════

function Scripts({ scripts }) {
  return (
    <div className="panel">
      <div className="panel-head">
        <span>Compatibility audit · 2026-05-25</span>
        <span style={{ color: "var(--muted)" }}>23 files checked</span>
      </div>
      <div className="panel-body">
        <div className="scripts-summary">
          <div className="item pass">
            <div className="num">{scripts.summary.pass}</div>
            <div className="label">pass · no edits needed</div>
          </div>
          <div className="item rewritten">
            <div className="num">{scripts.summary.rewritten}</div>
            <div className="label">rewritten for new API</div>
          </div>
          <div className="item new">
            <div className="num">{scripts.summary.new}</div>
            <div className="label">new test panels</div>
          </div>
        </div>
        <table className="scripts-table">
          <thead>
            <tr><th>file</th><th>last edit</th><th>status</th><th>notes</th></tr>
          </thead>
          <tbody>
            {scripts.rows.map((r) => (
              <tr key={r.file}>
                <td className="file">{r.file}</td>
                <td className="date">{r.date}</td>
                <td>
                  <Pill kind={r.status === "pass" ? "shipped" : r.status === "rewritten" ? "inprog" : "info"}>
                    {r.status}
                  </Pill>
                </td>
                <td className="notes">{r.notes || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Side-tasks
// ═════════════════════════════════════════════════════════════

function SideTasks({ tasks, cards }) {
  const [open, setOpen] = useState(null);
  const cardLookup = useMemo(() => {
    const m = new Map();
    cards.forEach((c) => m.set(c.id, c.title));
    return m;
  }, [cards]);

  return (
    <div>
      <div className="sidetasks">
        {tasks.map((t) => (
          <div key={t.id} className="sidetask">
            <span className="sidetask-num">{t.num}</span>
            <div style={{ position: "relative" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                <Pill kind={t.kind === "rework" ? "inprog" : t.kind === "fork" ? "info" : "tag"}>{t.kind}</Pill>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)" }}>
                  {t.upstream}
                </span>
              </div>
              <div className="sidetask-title">{t.title}</div>
              <div className="sidetask-path">{t.repoPath}</div>
              <div className="sidetask-summary">{t.summary}</div>

              <div className="sidetask-deps">
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 9.5, color: "var(--faint)", letterSpacing: "0.1em", textTransform: "uppercase", alignSelf: "center", marginRight: 4 }}>depends</span>
                {t.dependsOn.map((id) => (
                  <Pill key={id} kind="tag">{cardLookup.get(id) || id}</Pill>
                ))}
              </div>

              <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--muted)" }}>
                  {t.status}
                </span>
                <button
                  onClick={() => setOpen(open === t.id ? null : t.id)}
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: 10.5,
                    color: "var(--accent)",
                    textTransform: "uppercase",
                    letterSpacing: "0.1em",
                    border: "1px solid var(--line)",
                    padding: "5px 10px",
                    borderRadius: 3,
                  }}>
                  {open === t.id ? "− collapse" : "+ open"}
                </button>
              </div>

              {open === t.id && <SideTaskDetail task={t} />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SideTaskDetail({ task }) {
  return (
    <div style={{
      marginTop: 14, paddingTop: 14,
      borderTop: "1px dashed var(--line)",
      display: "flex", flexDirection: "column", gap: 14,
    }}>
      {task.verdict && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>Verdict breakdown</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6 }}>
            <VerdictTile n={task.verdict.keep}     label="keep"     color="var(--shipped)" />
            <VerdictTile n={task.verdict.rewrite}  label="rewrite"  color="var(--inprog)" />
            <VerdictTile n={task.verdict.obsolete} label="obsolete" color="var(--open)" />
            <VerdictTile n={task.verdict.audit}    label="audit"    color="var(--info)" />
          </div>
        </div>
      )}

      {task.modules && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>Module map · top by line count</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
            {task.modules.map((m) => <ModuleRow key={m.file} m={m} max={4085} />)}
          </div>
        </div>
      )}

      {task.newTools && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>New MCP tools to add</div>
          <ul className="card-list">
            {task.newTools.map((t, i) => <li key={i}>{t}</li>)}
          </ul>
        </div>
      )}

      {task.patternsToLift && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>Patterns to lift</div>
          <ul className="card-list">
            {task.patternsToLift.map((t, i) => <li key={i}>{t}</li>)}
          </ul>
        </div>
      )}

      {task.actions && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>Work order</div>
          <CheckList
            ownerId={`sidetask-${task.id}`}
            ownerTitle={task.title}
            items={task.actions.map(a => ({ label: a.label, done: a.status === "done" }))}
          />
        </div>
      )}

      {task.acceptance && (
        <div>
          <div className="card-section-label" style={{ marginBottom: 6 }}>Acceptance criteria</div>
          <ul className="card-list">
            {task.acceptance.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}

function VerdictTile({ n, label, color }) {
  return (
    <div style={{
      background: "var(--panel-2)",
      border: "1px solid var(--line)",
      borderRadius: 3,
      padding: "8px 10px",
      textAlign: "center",
    }}>
      <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color, fontWeight: 500, lineHeight: 1 }}>{n}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 9.5, color: "var(--muted)", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 2 }}>{label}</div>
    </div>
  );
}

function ModuleRow({ m, max }) {
  const lines = typeof m.lines === "number" ? m.lines : 0;
  const pct = (lines / max) * 100;
  const color =
    m.verdict === "keep" ? "var(--shipped)"
    : m.verdict === "rewrite" ? "var(--inprog)"
    : m.verdict === "obsolete" ? "var(--open)"
    : "var(--info)";
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "200px 1fr 60px 70px",
      gap: 8, alignItems: "center",
      fontFamily: "var(--font-mono)", fontSize: 10.5,
    }}>
      <span style={{ color: "var(--text-2)" }}>{m.file}</span>
      <span style={{ height: 8, background: "var(--bg)", borderRadius: 2, overflow: "hidden" }}>
        <span style={{ display: "block", height: "100%", width: `${pct}%`, background: color, opacity: 0.7 }}></span>
      </span>
      <span style={{ color: "var(--muted)", textAlign: "right" }}>{m.lines}</span>
      <span style={{ color, textTransform: "uppercase", letterSpacing: "0.08em", fontSize: 9.5, textAlign: "right" }}>{m.verdict}</span>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════
// Gallery — screenshots grid with lightbox. Hidden by default.
// Add images to data.meta.gallery: [{src, caption}].
// ═════════════════════════════════════════════════════════════

function Gallery({ items = [] }) {
  const [lightbox, setLightbox] = useState(null);

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e) => { if (e.key === "Escape") setLightbox(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox]);

  if (items.length === 0) {
    return (
      <div className="panel" style={{ padding: 24 }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--muted)" }}>
          No images yet. Add entries to <code>data.meta.gallery</code> as{" "}
          <code>{"[{src: 'uploads/img.png', caption: '...'}]"}</code>.
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="gallery-grid">
        {items.map((img, i) => (
          <div key={i} className="gallery-item" onClick={() => setLightbox(img)}>
            {img.src
              ? <img src={img.src} alt={img.caption} loading="lazy" />
              : <div className="gallery-placeholder">{img.caption || "No image"}</div>
            }
            <div className="gallery-caption">{img.caption}</div>
          </div>
        ))}
      </div>
      {lightbox && (
        <div className="gallery-lightbox" onClick={() => setLightbox(null)}>
          {lightbox.src
            ? <img src={lightbox.src} alt={lightbox.caption} />
            : <div style={{ color: "#fff", fontFamily: "var(--font-mono)" }}>No image file</div>
          }
          <div className="lb-caption">{lightbox.caption}</div>
        </div>
      )}
    </>
  );
}

function Footer({ meta }) {
  return (
    <footer className="footer">
      <span>UEVR · luavrlib branch · auto-generated from /docs · session {meta.sessionId}</span>
      <span>Claude Code · 3 progress docs · {meta.lastUpdated}</span>
    </footer>
  );
}

// ═════════════════════════════════════════════════════════════
// App
// ═════════════════════════════════════════════════════════════

function Dashboard() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [toolsOpen, setToolsOpen] = useState(false);
  const companion = useCompanion();
  const data = window.PROGRESS_DATA || window.UEVR_DATA;

  // Apply theme attr
  useEffect(() => {
    document.body.setAttribute("data-theme", t.theme);
    document.body.setAttribute("data-density", t.density);
  }, [t.theme, t.density]);

  // Esc closes tools drawer.
  useEffect(() => {
    if (!toolsOpen) return;
    const onKey = (e) => { if (e.key === "Escape") setToolsOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toolsOpen]);

  const mode = t.viewMode || "recruiter";
  const setMode = (v) => setTweak("viewMode", v);

  return (
    <>
      <ViewToggle mode={mode} onChange={setMode} />

      {mode === "recruiter" ? (
        <RecruiterView data={data} onSwitchToDev={() => setMode("dev")} />
      ) : (
        <DevDashboard data={data} t={t} setTweak={setTweak} companion={companion} onOpenTools={() => setToolsOpen(true)} />
      )}

      {mode === "dev" && toolsOpen && (
        <ToolsDrawer data={data} companion={companion} onClose={() => setToolsOpen(false)} />
      )}
      {mode === "dev" && !toolsOpen && (
        <ToolsFAB onOpen={() => setToolsOpen(true)} />
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Layout" />
        <TweakRadio
          label="View"
          value={mode}
          options={["recruiter", "dev"]}
          onChange={setMode}
        />
        <TweakSection label="Theme" />
        <TweakRadio
          label="Aesthetic"
          value={t.theme}
          options={["console", "daylight", "phosphor"]}
          onChange={(v) => setTweak("theme", v)}
        />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["compact", "comfortable"]}
          onChange={(v) => setTweak("density", v)}
        />
        {mode === "dev" && (
          <>
            <TweakSection label="Dev sections" />
            <TweakToggle label="Roadmap"      value={t.showRoadmap}    onChange={(v) => setTweak("showRoadmap", v)} />
            <TweakToggle label="Kanban"       value={t.showKanban}     onChange={(v) => setTweak("showKanban", v)} />
            <TweakToggle label="Dependencies" value={t.showDeps}       onChange={(v) => setTweak("showDeps", v)} />
            <TweakToggle label="Issues"       value={t.showIssues}     onChange={(v) => setTweak("showIssues", v)} />
            <TweakToggle label="Files"        value={t.showFiles}      onChange={(v) => setTweak("showFiles", v)} />
            <TweakToggle label="Scripts"      value={t.showScripts}    onChange={(v) => setTweak("showScripts", v)} />
            <TweakToggle label="Side-tasks"   value={t.showSideTasks}  onChange={(v) => setTweak("showSideTasks", v)} />
            <TweakToggle label="Gallery"      value={t.showGallery}    onChange={(v) => setTweak("showGallery", v)} />
          </>
        )}
      </TweaksPanel>
    </>
  );
}

function ViewToggle({ mode, onChange }) {
  return (
    <div className="view-toggle">
      <button className={mode === "recruiter" ? "active" : ""} onClick={() => onChange("recruiter")}>
        Overview
      </button>
      <button className={mode === "dev" ? "active" : ""} onClick={() => onChange("dev")}>
        Dev dashboard
      </button>
    </div>
  );
}

function DevDashboard({ data, t, setTweak, companion, onOpenTools }) {
  return (
    <div className="app">
      <HeaderStrip meta={data.meta} />
      <Vitals vitals={data.vitals} />

      {t.showRoadmap && (
        <section className="section">
          <SectionHead num="01" title="Roadmap" aside="2026-04-14 → next" />
          <Roadmap milestones={data.milestones} />
        </section>
      )}

      {t.showKanban && (
        <section className="section">
          <SectionHead num="02" title="Kanban · feature board" aside="click any card to expand" />
          <Kanban cards={data.cards} symptoms={data.symptoms} plan={data.plan} companion={companion} />
        </section>
      )}

      {t.showDeps && (
        <section className="section">
          <SectionHead num="03" title="Dependency map" aside="hover to trace" />
          <DepGraph data={data} />
        </section>
      )}

      {t.showIssues && (
        <section className="section">
          <SectionHead num="04" title="Open issues + fix plan" aside="multi-viewport · paused" />
          <Issues symptoms={data.symptoms} plan={data.plan} />
        </section>
      )}

      {t.showFiles && (
        <section className="section">
          <SectionHead num="05" title="Files touched" aside="11 files · 21 changes" />
          <FilesHeatmap files={data.files} />
        </section>
      )}

      {t.showScripts && (
        <section className="section">
          <SectionHead num="06" title="Lua scripts · compatibility" aside="23 user scripts" />
          <Scripts scripts={data.scripts} />
        </section>
      )}

      {t.showSideTasks && (
        <section className="section">
          <SectionHead num="07" title="Side-tasks · sibling repos" aside="3 hand-offs" />
          <SideTasks tasks={data.sideTasks} cards={data.cards} />
        </section>
      )}

      {t.showGallery && (
        <section className="section">
          <SectionHead num="08" title="Feature gallery" aside={`${(data.meta.gallery || []).length} images`} />
          <Gallery items={data.meta.gallery || []} />
        </section>
      )}

      <Footer meta={data.meta} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Dashboard />);
