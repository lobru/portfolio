// tools.jsx — scriptable tools that run from the dashboard.
// AI-powered: sync from docs, status report, release notes (via window.claude.complete).
// Scaffold: build script, deploy checklist (templated based on project meta).
// Export: snapshot the current data.js, download artifacts.

const { useState: useToolState, useEffect: useToolEffect } = React;

const TOOL_DEFS = [
  {
    id: "companion",
    name: "Companion server",
    kind: "local",
    blurb: "Generate + configure the local Python companion server. Enables Run buttons and the Ask Claude CLI feature on every card.",
  },
  {
    id: "sync",
    name: "Sync from docs",
    kind: "ai",
    blurb: "Paste new Claude Code markdown. Claude extracts shipped features, open issues, plan items, and proposes patches to data.js.",
  },
  {
    id: "report",
    name: "Generate status report",
    kind: "ai",
    blurb: "One-paragraph human-readable summary of where the project stands. Good for stand-ups, weekly updates, or pinging stakeholders.",
  },
  {
    id: "release",
    name: "Draft release notes",
    kind: "ai",
    blurb: "Markdown release notes for the shipped features since a given date. Group by area, plain-English, ready to paste into a GitHub release.",
  },
  {
    id: "buildscript",
    name: "Build script (Windows / Linux)",
    kind: "scaffold",
    blurb: "Generate a build script tailored to this project's toolchain. When companion is running, hit Run to execute directly instead of downloading.",
  },
  {
    id: "deploy",
    name: "Deploy checklist",
    kind: "scaffold",
    blurb: "Pre-deploy checklist derived from current open issues + the fix plan. Download or Run via companion.",
  },
  {
    id: "mcp",
    name: "MCP setup",
    kind: "local",
    blurb: "Generate an MCP stdio server that exposes companion tools to Claude Code. Download mcp_server.py, get the claude mcp add command, and test the connection.",
  },
  {
    id: "notes",
    name: "Export all issue notes",
    kind: "export",
    blurb: "Bundle every card that has saved notes into one handoff markdown file — ready to paste into a new Claude session or another AI.",
  },
  {
    id: "snapshot",
    name: "Snapshot data.js",
    kind: "export",
    blurb: "Download the current data.js verbatim so this point-in-time view can be archived or re-loaded later.",
  },
];

function ToolsFAB({ onOpen }) {
  return (
    <button className="tools-fab" onClick={onOpen} title="Open tools drawer">
      <span className="fab-dot"></span>
      Tools
    </button>
  );
}

function ToolsDrawer({ data, companion, onClose }) {
  const [active, setActive] = useToolState(null);
  return (
    <>
      <div className="tools-overlay" onClick={onClose}></div>
      <aside className="tools-drawer">
        <div className="tools-drawer-head">
          <span className="tools-drawer-title">Tools</span>
          <button className="tools-drawer-close" onClick={onClose}>esc · close</button>
        </div>
        <div className="tools-drawer-body">
          <CompanionBanner companion={companion} />
          {TOOL_DEFS.map((t) => (
            <div key={t.id}>
              <div className={"tool-card " + (active === t.id ? "active" : "")}
                   onClick={() => setActive(active === t.id ? null : t.id)}>
                <div className="tool-card-head">
                  <span className="tool-card-name">{t.name}</span>
                  <span className={"tool-card-kind " + t.kind}>{t.kind}</span>
                </div>
                <div className="tool-card-blurb">{t.blurb}</div>
              </div>
              {active === t.id && <ToolBody id={t.id} data={data} companion={companion} />}
            </div>
          ))}
        </div>
      </aside>
    </>
  );
}

// ───────────── Per-tool body ─────────────

function ToolBody({ id, data, companion }) {
  switch (id) {
    case "companion":   return <CompanionTool companion={companion} />;
    case "sync":        return <SyncTool data={data} />;
    case "report":      return <ReportTool data={data} />;
    case "release":     return <ReleaseTool data={data} />;
    case "buildscript": return <BuildScriptTool data={data} companion={companion} />;
    case "deploy":      return <DeployTool data={data} companion={companion} />;
    case "mcp":         return <McpSetupTool companion={companion} data={data} />;
    case "notes":       return <ExportNotesTool data={data} />;
    case "snapshot":    return <SnapshotTool data={data} />;
    default:            return null;
  }
}

// ───────────── Helpers ─────────────

function useClaudeRun() {
  const [status, setStatus] = useToolState("idle");  // idle | working | ok | err
  const [output, setOutput] = useToolState("");
  const [err, setErr] = useToolState("");
  const run = async (prompt) => {
    setStatus("working"); setOutput(""); setErr("");
    try {
      if (!window.claude || !window.claude.complete) {
        throw new Error("window.claude.complete is unavailable in this preview. Open the published artifact (or your shared link) to use AI tools.");
      }
      const text = await window.claude.complete(prompt);
      setOutput(text); setStatus("ok");
    } catch (e) {
      setErr(String(e?.message || e)); setStatus("err");
    }
  };
  return { status, output, err, run, setOutput };
}

function copyToClipboard(text) {
  if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text);
}

function downloadText(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function StatusLine({ status, err, okText = "ready" }) {
  if (status === "idle") return null;
  const cls =
    status === "working" ? "working"
    : status === "err" ? "err"
    : "ok";
  return (
    <div className={"tool-status " + cls}>
      {status === "working" && "▮ Claude is thinking…"}
      {status === "ok" && `✓ ${okText}`}
      {status === "err" && `✗ ${err}`}
    </div>
  );
}

function OutputBlock({ text, downloadName, downloadMime = "text/markdown" }) {
  if (!text) return null;
  return (
    <>
      <pre className="tool-output">{text}</pre>
      <div className="tool-actions">
        <button className="tool-btn" onClick={() => copyToClipboard(text)}>Copy</button>
        {downloadName && (
          <button className="tool-btn" onClick={() => downloadText(downloadName, text, downloadMime)}>
            Download {downloadName}
          </button>
        )}
      </div>
    </>
  );
}

// ───────────── Companion config + generator ─────────────

function CompanionTool({ companion }) {
  const { port, setPort, repoPath, setRepoPath, status } = companion;
  const [downloaded, setDownloaded] = useToolState(false);
  const [runOutput, setRunOutput] = useToolState("");
  const connected = status === "connected";

  const download = () => {
    const src = window.generateCompanionPy(port);
    const blob = new Blob([src], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "companion.py";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    setDownloaded(true);
  };

  return (
    <div className="tool-body">
      <div className="tool-card-blurb" style={{ marginBottom: 8 }}>
        A zero-dependency Python 3 server that bridges this dashboard to your local machine.
        Run it from your repo root once — it stays alive in the background.
      </div>

      <div className="card-section-label">Configuration</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        <div>
          <div className="tool-status" style={{ marginBottom: 4 }}>Port</div>
          <input
            type="number" value={port}
            onChange={e => setPort(Number(e.target.value))}
            style={{
              width: "100%", padding: "7px 10px",
              background: "var(--panel)", color: "var(--text)",
              border: "1px solid var(--line)", borderRadius: 3,
              fontFamily: "var(--font-mono)", fontSize: 12,
            }}
          />
        </div>
        <div>
          <div className="tool-status" style={{ marginBottom: 4 }}>Repo root (optional override)</div>
          <input
            type="text" value={repoPath} placeholder="e.g. I:/code/lobotomy-x/UEVR"
            onChange={e => setRepoPath(e.target.value)}
            style={{
              width: "100%", padding: "7px 10px",
              background: "var(--panel)", color: "var(--text)",
              border: "1px solid var(--line)", borderRadius: 3,
              fontFamily: "var(--font-mono)", fontSize: 12,
            }}
          />
        </div>
      </div>

      <div className="tool-actions" style={{ marginTop: 6 }}>
        <button className="tool-btn primary" onClick={download}>
          {downloaded ? "Re-download companion.py" : "Download companion.py"}
        </button>
      </div>

      {downloaded && (
        <div className="tool-output" style={{ marginTop: 8, fontSize: 11 }}>
{`# Run from your repo root:
python companion.py --port ${port}

# Or with explicit Claude CLI path:
CLAUDE_CLI=/usr/local/bin/claude python companion.py

# On Windows PowerShell:
$env:CLAUDE_CLI="C:\\path\\to\\claude.exe"; python companion.py --port ${port}`}
        </div>
      )}

      {connected && (
        <div className={"tool-status ok"} style={{ marginTop: 6 }}>
          ✓ Companion connected · Run buttons and Ask Claude are now active on all cards.
        </div>
      )}
    </div>
  );
}

function SyncTool({ data }) {
  const [pasted, setPasted] = useToolState("");
  const { status, output, err, run } = useClaudeRun();

  const onRun = () => {
    if (!pasted.trim()) return;
    const prompt = `You are updating the data model behind a progress dashboard.

CURRENT data.js excerpt — these are the shapes you must keep:

cards[]: { id, title, status: "shipped"|"in-progress"|"open", group, tags[], blurb, detail?, files?[] }
symptoms[]: { id, title, detail, severity: "high"|"medium"|"low" }
plan[]: { step, title, detail, checks?[], state }
milestones[]: { date, label, kind: "ship"|"in-progress"|"audit"|"next", cardId? }
files[]: { path, domain, changeCount, changes[] }

CURRENT card ids in use (don't duplicate): ${data.cards.map(c => c.id).join(", ")}.

The user just pasted new Claude Code progress notes. Extract any NEW shipped features, in-progress fixes, open issues, plan items, milestones, or file changes. Output a JSON object with the shape:

{
  "newCards": [ {id, title, status, group, tags, blurb, detail?, files?} ],
  "newSymptoms": [ ... ],
  "newPlanItems": [ ... ],
  "newMilestones": [ ... ],
  "newFiles": [ ... ],
  "vitalsDelta": { "shipped": +N, "open": ±N, ... },
  "notes": "one-line summary of what changed"
}

Skip any object type that has no new entries. Use kebab-case for ids. Keep blurbs ≤ 18 words. Do NOT echo back content already in the existing dataset.

PASTED CLAUDE CODE NOTES:
---
${pasted}
---

Return ONLY the JSON object, no preamble.`;
    run(prompt);
  };

  return (
    <div className="tool-body">
      <div className="tool-card-blurb">
        Paste new markdown / notes from a Claude Code session. The model returns a JSON patch you can apply to data.js.
      </div>
      <textarea
        placeholder="Paste new Claude Code output here — shipped features, open issues, plan items, milestone log…"
        value={pasted}
        onChange={(e) => setPasted(e.target.value)}
      />
      <div className="tool-actions">
        <button className="tool-btn primary" onClick={onRun} disabled={!pasted.trim() || status === "working"}>
          Extract patch
        </button>
        <button className="tool-btn" onClick={() => setPasted("")} disabled={!pasted}>Clear</button>
      </div>
      <StatusLine status={status} err={err} okText="JSON patch ready" />
      <OutputBlock text={output} downloadName="data-patch.json" downloadMime="application/json" />
    </div>
  );
}

// ───────────── Status report ─────────────

function ReportTool({ data }) {
  const { status, output, err, run } = useClaudeRun();
  const onRun = () => {
    const shipped = data.cards.filter(c => c.status === "shipped").length;
    const inprog = data.cards.filter(c => c.status === "in-progress").length;
    const issues = data.symptoms.length;
    const recent = data.milestones.filter(m => m.kind === "ship" || m.kind === "in-progress").slice(-6);
    const prompt = `Write a 4-sentence status report for the ${data.meta.project} project (${data.meta.branch} branch), suitable for posting in a team channel.

Numbers: ${shipped} shipped, ${inprog} in progress, ${issues} open issues.

Recent milestones:
${recent.map(m => "- " + m.date + " · " + m.label).join("\n")}

Open issues:
${data.symptoms.map(s => "- " + s.title + " (" + s.severity + ")").join("\n")}

Plan to unblock:
${data.plan.slice(0, 2).map(p => "- §" + p.step + " " + p.title).join("\n")}

Tone: confident, plain English, no marketing fluff. End with the single biggest unblocker. No bullet lists, prose only.`;
    run(prompt);
  };
  return (
    <div className="tool-body">
      <div className="tool-actions">
        <button className="tool-btn primary" onClick={onRun} disabled={status === "working"}>Generate report</button>
      </div>
      <StatusLine status={status} err={err} okText="report drafted" />
      <OutputBlock text={output} downloadName="status-report.md" />
    </div>
  );
}

// ───────────── Release notes ─────────────

function ReleaseTool({ data }) {
  const { status, output, err, run } = useClaudeRun();
  const onRun = () => {
    const shipped = data.cards.filter(c => c.status === "shipped");
    const byGroup = {};
    shipped.forEach(c => {
      (byGroup[c.group] = byGroup[c.group] || []).push(c);
    });
    const groupsText = Object.entries(byGroup).map(([g, cs]) => {
      return `### ${g}\n` + cs.map(c => `- ${c.title} — ${c.blurb}`).join("\n");
    }).join("\n\n");

    const prompt = `Draft Markdown release notes for the ${data.meta.project} ${data.meta.branch} branch, suitable for a GitHub release.

Shipped, grouped:

${groupsText}

Format:
- ## tagline (one line, punchy, ≤ 14 words)
- Short intro paragraph (2 sentences)
- Sections: "New", "Bug fixes", "Rewrites/cleanups" — combine across groups intelligently
- Bullet items: keep blurb plain English; trim jargon where you can
- Footer: "Known issues" — list the open symptoms briefly

Return only the markdown, no preamble.`;
    run(prompt);
  };
  return (
    <div className="tool-body">
      <div className="tool-actions">
        <button className="tool-btn primary" onClick={onRun} disabled={status === "working"}>Draft release notes</button>
      </div>
      <StatusLine status={status} err={err} okText="release notes drafted" />
      <OutputBlock text={output} downloadName={`RELEASE-${data.meta.branch}.md`} />
    </div>
  );
}

// ───────────── Build script ─────────────

function BuildScriptTool({ data, companion }) {
  const [os, setOs] = useToolState("windows");
  const [config, setConfig] = useToolState("RelWithDebInfo");
  const [runStatus, setRunStatus] = useToolState("idle");
  const [runOutput, setRunOutput] = useToolState("");
  const connected = companion?.status === "connected";
  const text = renderBuildScript(os, config, data);

  const onRun = async () => {
    setRunStatus("working"); setRunOutput("");
    const res = await companion.runScript(text, os === "windows" ? "ps1" : "sh");
    if (res.error) {
      setRunOutput(res.error); setRunStatus("err");
    } else {
      setRunOutput((res.stdout || "") + (res.stderr ? "\n[stderr]\n" + res.stderr : ""));
      setRunStatus(res.returncode === 0 ? "ok" : "err");
    }
  };

  return (
    <div className="tool-body">
      <div className="tool-actions">
        <button className={"tool-btn" + (os === "windows" ? " primary" : "")} onClick={() => setOs("windows")}>Windows · PowerShell</button>
        <button className={"tool-btn" + (os === "linux" ? " primary" : "")} onClick={() => setOs("linux")}>Linux · bash</button>
      </div>
      <div className="tool-actions">
        {["Debug", "RelWithDebInfo", "Release"].map(c => (
          <button key={c} className={"tool-btn" + (config === c ? " primary" : "")} onClick={() => setConfig(c)}>{c}</button>
        ))}
      </div>
      <OutputBlock
        text={text}
        downloadName={os === "windows" ? "build.ps1" : "build.sh"}
        downloadMime={os === "windows" ? "application/x-powershell" : "application/x-sh"}
      />
      <div className="tool-actions">
        {connected ? (
          <button className="tool-btn primary" onClick={onRun} disabled={runStatus === "working"}>
            {runStatus === "working" ? "▮ Building…" : "▶ Run via companion"}
          </button>
        ) : (
          <div className="tool-status">○ Start companion.py to enable Run</div>
        )}
      </div>
      {runOutput && (
        <pre className="tool-output" style={{ color: runStatus === "err" ? "var(--open)" : "var(--text)" }}>
          {runOutput}
        </pre>
      )}
      <StatusLine status={runStatus} err={runOutput} okText={`build exited 0`} />
    </div>
  );
}

function renderBuildScript(os, config, data) {
  const repo = data.meta.repoPath || "<repo-path>";
  const project = data.meta.project;
  const branch = data.meta.branch;
  if (os === "windows") {
    return `# build.ps1 — ${project} (${branch})
# Generated by Progress Dashboard · ${data.meta.lastUpdated}

$ErrorActionPreference = "Stop"
$RepoRoot = "${repo}"
$BuildDir = Join-Path $RepoRoot "build"
$Config   = "${config}"

Push-Location $RepoRoot
try {
  Write-Host "[1/4] Verifying branch · expecting ${branch}"
  git rev-parse --abbrev-ref HEAD

  Write-Host "[2/4] Configuring CMake · $Config"
  if (-not (Test-Path $BuildDir)) { New-Item -ItemType Directory $BuildDir | Out-Null }
  cmake -S . -B $BuildDir -A x64

  Write-Host "[3/4] Building · $Config"
  cmake --build $BuildDir --config $Config -- /m

  Write-Host "[4/4] Done · artifacts in $BuildDir\\bin\\$Config"
} finally {
  Pop-Location
}
`;
  }
  return `#!/usr/bin/env bash
# build.sh — ${project} (${branch})
# Generated by Progress Dashboard · ${data.meta.lastUpdated}

set -euo pipefail
REPO_ROOT="${repo}"
BUILD_DIR="$REPO_ROOT/build"
CONFIG="${config}"

cd "$REPO_ROOT"

echo "[1/4] Verifying branch · expecting ${branch}"
git rev-parse --abbrev-ref HEAD

echo "[2/4] Configuring CMake · $CONFIG"
mkdir -p "$BUILD_DIR"
cmake -S . -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE="$CONFIG"

echo "[3/4] Building · $CONFIG"
cmake --build "$BUILD_DIR" --config "$CONFIG" -- -j"$(nproc)"

echo "[4/4] Done · artifacts in $BUILD_DIR"
`;
}

// ───────────── Deploy checklist ─────────────

function DeployTool({ data, companion }) {
  const [runStatus, setRunStatus] = useToolState("idle");
  const [runOutput, setRunOutput] = useToolState("");
  const connected = companion?.status === "connected";
  const text = renderDeployChecklist(data);

  const onRun = async () => {
    setRunStatus("working"); setRunOutput("");
    // Runs the checklist as a validation script that echoes each item
    const script = `echo "=== Deploy checklist · ${data.meta.project} · ${data.meta.branch} ==="\necho "Open in your editor to check items off."\necho ""\necho "Companion confirms: build environment is reachable."\npython --version 2>&1 || true`;
    const res = await companion.runScript(script, "sh");
    if (res.error) { setRunOutput(res.error); setRunStatus("err"); }
    else {
      setRunOutput((res.stdout || "") + (res.stderr || ""));
      setRunStatus("ok");
    }
  };

  return (
    <div className="tool-body">
      <OutputBlock text={text} downloadName="DEPLOY.md" />
      <div className="tool-actions">
        {connected ? (
          <button className="tool-btn primary" onClick={onRun} disabled={runStatus === "working"}>
            {runStatus === "working" ? "▮ Running…" : "▶ Verify environment via companion"}
          </button>
        ) : (
          <div className="tool-status">○ Start companion.py to verify environment</div>
        )}
      </div>
      {runOutput && (
        <pre className="tool-output">{runOutput}</pre>
      )}
    </div>
  );
}

function renderDeployChecklist(data) {
  const lines = [];
  lines.push(`# Deploy checklist · ${data.meta.project} · ${data.meta.branch}`);
  lines.push(`_Generated ${data.meta.lastUpdated}_`);
  lines.push("");
  lines.push("## Blockers — must be resolved before deploy");
  if (data.symptoms.length === 0) lines.push("- _none_");
  data.symptoms.forEach((s) => {
    lines.push(`- [ ] **(${s.severity})** ${s.title}`);
    lines.push(`      ↳ ${s.detail}`);
  });
  lines.push("");
  lines.push("## Fix-plan acceptance");
  data.plan.forEach((p) => {
    lines.push(`- [ ] **§${p.step} — ${p.title}**`);
    (p.checks || []).forEach((c) => lines.push(`  - [ ] ${c}`));
  });
  lines.push("");
  lines.push("## Verify shipped features still work");
  data.cards.filter((c) => c.status === "shipped").slice(0, 8).forEach((c) => {
    lines.push(`- [ ] ${c.title} — ${c.blurb}`);
  });
  lines.push("");
  lines.push("## Build & smoke-test");
  lines.push(`- [ ] Run \`build.ps1\` / \`build.sh\` on ${data.meta.repoPath || "<repo>"}`);
  lines.push("- [ ] Inject into a known-good target game and confirm overlay renders");
  lines.push("- [ ] Run `Scripts/Tests/new_api_panels.lua` and tick every panel green");
  lines.push("- [ ] Spawn one worker thread, verify shared map round-trip");
  lines.push("- [ ] Re-baseline screenshots if UI surface changed");
  lines.push("");
  lines.push("## Release");
  lines.push("- [ ] Tag the commit · `git tag -a luavrlib-<date> -m \"…\"`");
  lines.push("- [ ] Generate release notes via the dashboard's 'Draft release notes' tool");
  lines.push("- [ ] Publish GitHub release · attach build artifacts");
  lines.push("- [ ] Update side-task hand-offs that depended on this drop");
  return lines.join("\n");
}

// ───────────── MCP setup ─────────────

function generateMcpServerPy(port = 7373) {
  return `#!/usr/bin/env python3
"""mcp_server.py — MCP stdio server for the Progress Dashboard.
Wraps the companion HTTP server (companion.py must be running on PORT).
Zero external dependencies — pure stdlib.

SETUP (run once):
  claude mcp add progress-dashboard -- python /path/to/mcp_server.py

Or add to claude_desktop_config.json:
  {
    "mcpServers": {
      "progress-dashboard": {
        "command": "python",
        "args": ["/ABSOLUTE/PATH/TO/mcp_server.py"]
      }
    }
  }

Then test inside Claude Code:
  Use MCP tool: dashboard_status
"""

import json, sys, urllib.request

PORT = ${port}
BASE = f"http://localhost:{PORT}"

TOOLS = [
    {
        "name": "dashboard_status",
        "description": "Check companion health and get project snapshot (branch, last update, vitals).",
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "dashboard_run_script",
        "description": "Execute a build or deploy script on the local machine.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "script": {"type": "string", "description": "Shell script content"},
                "type":   {"type": "string", "enum": ["ps1","sh"], "description": "ps1 = PowerShell, sh = bash"},
            },
            "required": ["script"],
        },
    },
    {
        "name": "dashboard_ask_claude_cli",
        "description": "Run a prompt through the local Claude CLI and return the response.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Prompt text"},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "dashboard_export_notes",
        "description": "Return all saved issue notes from the dashboard as a markdown string.",
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
]

def http_get(path):
    try:
        with urllib.request.urlopen(f"{BASE}{path}", timeout=5) as r:
            return json.loads(r.read())
    except Exception as e:
        return {"error": str(e)}

def http_post(path, body):
    try:
        data = json.dumps(body).encode()
        req  = urllib.request.Request(f"{BASE}{path}", data=data,
                                      headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())
    except Exception as e:
        return {"error": str(e)}

def call_tool(name, args):
    if name == "dashboard_status":
        return http_get("/status")
    if name == "dashboard_run_script":
        return http_post("/run", args)
    if name == "dashboard_ask_claude_cli":
        return http_post("/claude", args)
    if name == "dashboard_export_notes":
        return http_get("/notes")   # companion serves this if implemented
    return {"error": f"Unknown tool: {name}"}

def handle(msg):
    method = msg.get("method", "")
    params = msg.get("params", {})
    if method == "initialize":
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "progress-dashboard", "version": "1.0.0"},
        }
    if method == "notifications/initialized":
        return None   # no response needed
    if method == "tools/list":
        return {"tools": TOOLS}
    if method == "tools/call":
        result = call_tool(params.get("name",""), params.get("arguments", {}))
        return {
            "content": [{"type": "text", "text": json.dumps(result, indent=2)}],
            "isError": "error" in result,
        }
    return {"error": {"code": -32601, "message": f"Unknown method: {method}"}}

def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg  = json.loads(line)
            res  = handle(msg)
            if res is None:
                continue
            resp = {"jsonrpc": "2.0", "id": msg.get("id")}
            if isinstance(res, dict) and "error" in res and not "content" in res:
                resp["error"] = res["error"] if isinstance(res["error"], dict) \
                    else {"code": -32000, "message": str(res["error"])}
            else:
                resp["result"] = res
            print(json.dumps(resp), flush=True)
        except Exception as e:
            print(json.dumps({"jsonrpc": "2.0", "id": None,
                              "error": {"code": -32700, "message": str(e)}}), flush=True)

if __name__ == "__main__":
    main()
`;
}

function McpSetupTool({ companion, data }) {
  const port = companion?.port || 7373;
  const connected = companion?.status === "connected";
  const [tested, setTested] = useToolState(null); // null | ok | err

  const onTest = async () => {
    setTested(null);
    const res = await (companion?.askClaude?.("echo 'mcp test ok'") || Promise.resolve({ error: "companion not connected" }));
    setTested(res.error ? "err" : "ok");
  };

  const downloadMcp = () => downloadText("mcp_server.py", generateMcpServerPy(port), "text/x-python");

  const mcpAddCmd = `claude mcp add progress-dashboard -- python /path/to/mcp_server.py`;
  const configJson = JSON.stringify({
    mcpServers: {
      "progress-dashboard": {
        command: "python",
        args: ["/ABSOLUTE/PATH/TO/mcp_server.py"],
      },
    },
  }, null, 2);

  return (
    <div className="tool-body">
      <div className="tool-card-blurb">
        Generates a zero-dependency Python MCP stdio server that wraps the companion HTTP server. Register it with Claude Code in one command.
      </div>

      <div className="card-section-label" style={{ marginTop: 4 }}>Step 1 — companion server</div>
      <div className="tool-status" style={{ marginBottom: 8 }}>
        {connected
          ? <span className="ok">✓ Companion running on localhost:{port}</span>
          : <span>○ Start companion.py first (Tools → Companion server)</span>}
      </div>

      <div className="card-section-label">Step 2 — MCP server</div>
      <div className="tool-actions">
        <button className="tool-btn primary" onClick={downloadMcp}>Download mcp_server.py</button>
      </div>

      <div className="card-section-label" style={{ marginTop: 10 }}>Step 3 — register with Claude Code</div>
      <pre className="tool-output" style={{ userSelect: "all", cursor: "copy" }}>{mcpAddCmd}</pre>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)", marginTop: 2 }}>
        Replace /path/to/mcp_server.py with the absolute path on your machine.
      </div>

      <div className="card-section-label" style={{ marginTop: 10 }}>Or: add to claude_desktop_config.json</div>
      <pre className="tool-output" style={{ userSelect: "all" }}>{configJson}</pre>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)", marginTop: 2 }}>
        Mac: ~/Library/Application Support/Claude/claude_desktop_config.json{"\n"}
        Win: %APPDATA%\Claude\claude_desktop_config.json
      </div>

      <div className="card-section-label" style={{ marginTop: 10 }}>Step 4 — test</div>
      <div className="tool-actions">
        <button className="tool-btn" onClick={onTest} disabled={!connected}>Test via companion</button>
        {tested === "ok" && <span className="tool-status ok">✓ Claude CLI responded</span>}
        {tested === "err" && <span className="tool-status err">✗ Check companion is running + Claude CLI in PATH</span>}
      </div>

      <div className="card-section-label" style={{ marginTop: 10 }}>Available MCP tools</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, lineHeight: 1.7, color: "var(--text-2)" }}>
        {[
          "dashboard_status       — health check + project snapshot",
          "dashboard_run_script   — execute build/deploy script",
          "dashboard_ask_claude_cli — prompt → Claude CLI response",
          "dashboard_export_notes — all saved issue notes as markdown",
        ].map((l, i) => <div key={i}>{l}</div>)}
      </div>
    </div>
  );
}

function ExportNotesTool({ data }) {
  const [preview, setPreview] = useToolState("");
  const [count,   setCount]   = useToolState(0);

  const generate = () => {
    const allNotes = window.getAllNotes ? window.getAllNotes() : {};
    const noteIds = Object.keys(allNotes);
    if (noteIds.length === 0) {
      setPreview("No notes found. Expand any card and write notes in the Notes field first.");
      setCount(0);
      return;
    }

    // Gather all cards + symptoms + plan-as-cards
    const allCards = [
      ...(data.cards || []),
      ...(data.symptoms || []).map(s => ({
        id: s.id, title: s.title, status: "open",
        group: s.kind === "feature" ? "Backlog" : "Symptom",
        tags: [s.severity || s.kind || "open"], blurb: s.detail,
      })),
      ...(data.plan || []).map(p => ({
        id: "plan-" + p.step, title: `Plan §${p.step}: ${p.title}`,
        status: "open", group: "Fix plan", tags: ["next"], blurb: p.detail,
      })),
    ];

    const lines = [];
    lines.push(`# Issue notes export — ${data.meta?.project || "Project"} · ${data.meta?.branch || ""}`);
    lines.push(`_${noteIds.length} issue${noteIds.length !== 1 ? "s" : ""} with notes · ${new Date().toISOString().slice(0,10)}_`);
    lines.push("");
    lines.push("---");
    lines.push("");
    lines.push("## Quick index");
    noteIds.forEach(id => {
      const card = allCards.find(c => c.id === id);
      lines.push(`- ${card ? card.title : id}`);
    });
    lines.push("");
    lines.push("---");
    lines.push("");

    noteIds.forEach((id, i) => {
      const card = allCards.find(c => c.id === id) || { id, title: id, status: "open", group: "?", blurb: "" };
      const pack = window.buildContextPack(card, allNotes[id], data);
      lines.push(pack);
      if (i < noteIds.length - 1) { lines.push(""); lines.push("---"); lines.push(""); }
    });

    const full = lines.join("\n");
    setPreview(full.slice(0, 1000) + (full.length > 1000 ? `\n…(${full.length - 1000} more chars in download)` : ""));
    setCount(noteIds.length);
    return full;
  };

  const onGenerate = () => generate();

  const onExport = () => {
    const allNotes = window.getAllNotes ? window.getAllNotes() : {};
    const noteIds = Object.keys(allNotes);
    if (!noteIds.length) { generate(); return; }
    const allCards = [
      ...(data.cards || []),
      ...(data.symptoms || []).map(s => ({
        id: s.id, title: s.title, status: "open",
        group: s.kind === "feature" ? "Backlog" : "Symptom",
        tags: [s.severity || s.kind || "open"], blurb: s.detail,
      })),
      ...(data.plan || []).map(p => ({
        id: "plan-" + p.step, title: `Plan §${p.step}: ${p.title}`,
        status: "open", group: "Fix plan", tags: ["next"], blurb: p.detail,
      })),
    ];
    const lines = [
      `# Issue notes export — ${data.meta?.project || "Project"} · ${data.meta?.branch || ""}`,
      `_${noteIds.length} issue${noteIds.length !== 1 ? "s" : ""} with notes · ${new Date().toISOString().slice(0,10)}_`,
      "", "---", "",
      "## Quick index",
      ...noteIds.map(id => { const c = allCards.find(c => c.id === id); return `- ${c ? c.title : id}`; }),
      "", "---", "",
    ];
    noteIds.forEach((id, i) => {
      const card = allCards.find(c => c.id === id) || { id, title: id, status: "open", group: "?", blurb: "" };
      lines.push(window.buildContextPack(card, allNotes[id], data));
      if (i < noteIds.length - 1) lines.push("", "---", "");
    });
    downloadText(`notes-export-${new Date().toISOString().slice(0,10)}.md`, lines.join("\n"));
  };

  return (
    <div className="tool-body">
      <div className="tool-card-blurb">
        Finds every card with saved notes in localStorage and compiles them into one structured markdown handoff doc — full context, plan refs, and your notes ready for a fresh Claude session.
      </div>
      <div className="tool-actions">
        <button className="tool-btn" onClick={onGenerate}>Preview</button>
        <button className="tool-btn primary" onClick={onExport}>Export .md</button>
        <button className="tool-btn" onClick={async () => {
          const allNotes = window.getAllNotes ? window.getAllNotes() : {};
          if (!Object.keys(allNotes).length) { onGenerate(); return; }
          const allCards = [
            ...(data.cards || []),
            ...(data.symptoms || []).map(s => ({ id: s.id, title: s.title, status: "open", group: s.kind === "feature" ? "Backlog" : "Symptom", tags: [s.severity || "open"], blurb: s.detail })),
            ...(data.plan || []).map(p => ({ id: "plan-" + p.step, title: `Plan §${p.step}: ${p.title}`, status: "open", group: "Fix plan", tags: ["next"], blurb: p.detail })),
          ];
          const lines = [`# Notes export — ${data.meta?.project || ""}`, ""];
          Object.keys(allNotes).forEach((id, i) => {
            const card = allCards.find(c => c.id === id) || { id, title: id, status: "open", group: "?", blurb: "" };
            lines.push(window.buildContextPack(card, allNotes[id], data));
            if (i < Object.keys(allNotes).length - 1) lines.push("", "---", "");
          });
          try { await navigator.clipboard.writeText(lines.join("\n")); } catch {}
        }}>Copy all to clipboard</button>
      </div>
      {count > 0 && (
        <div className="tool-status ok">✓ {count} issue{count !== 1 ? "s" : ""} with notes found</div>
      )}
      {preview && <pre className="tool-output">{preview}</pre>}
    </div>
  );
}

function SnapshotTool({ data }) {
  const text = "// data.js · snapshot " + data.meta.lastUpdated + "\n" +
               "window.PROGRESS_DATA = " + JSON.stringify(data, null, 2) + ";";
  return (
    <div className="tool-body">
      <div className="tool-status">
        Downloads the current dataset verbatim. Useful for archiving point-in-time state or feeding into another tool.
      </div>
      <OutputBlock
        text={text.slice(0, 1200) + (text.length > 1200 ? "\n…(" + (text.length - 1200) + " more chars in download)" : "")}
        downloadName={`data-${data.meta.lastUpdated}.js`}
        downloadMime="application/javascript"
      />
    </div>
  );
}

window.ToolsFAB = ToolsFAB;
window.ToolsDrawer = ToolsDrawer;
