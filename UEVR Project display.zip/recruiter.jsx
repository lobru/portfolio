// recruiter.jsx — Overview tab for UEVR · luavrlib dashboard
// Layout per design handoff: topbar → identity → sprint strip → body sections
// Hero is FULL WIDTH, NOT two-column. Three stacked zones.

function RecruiterView({ data, onSwitchToDev }) {
  const m = data.meta;

  const highlightCards = (m.highlights || [])
    .map((id) => data.cards.find((c) => c.id === id))
    .filter(Boolean);

  const shippedMilestones = data.milestones.filter(
    (x) => x.kind === "ship" || x.kind === "in-progress"
  );

  // Dynamic section numbers based on what's populated
  let secN = 0;
  const nextSec = () => String(++secN).padStart(2, "0");

  return (
    <div className="rec">

      {/* ══════════════ HERO ══════════════ */}
      <header className="rec-hero-v2">

        {/* Zone 1 — Topbar */}
        <div className="rec-topbar">
          <a href="Portfolio.html" className="rec-back-link">← Logan Brunet · Portfolio</a>
          <nav className="rec-topbar-nav">
            {m.github    && <a href={m.github}    target="_blank" rel="noopener noreferrer" className="rec-topbar-link">GitHub ↗</a>}
            {m.linkedIn  && <a href={m.linkedIn}  target="_blank" rel="noopener noreferrer" className="rec-topbar-link">LinkedIn ↗</a>}
            <a href="#dev" className="rec-topbar-link"
               onClick={(e) => { e.preventDefault(); onSwitchToDev(); }}>Dev dashboard ↗</a>
          </nav>
        </div>

        {/* Zone 2 — Identity */}
        <div className="rec-identity">
          <div className="rec-identity-main">
            {/* Left: name + byline + desc */}
            <div className="rec-identity-text">
              <h1 className="rec-name">{m.project}</h1>
              <div className="rec-role-line">Contributed by {m.author}</div>
              {m.description && <p className="rec-bio">{m.description}</p>}
            </div>
            {/* Right: built-with chips */}
            {m.techStack && m.techStack.length > 0 && (
              <div className="rec-tech-chips">
                <div className="rec-tech-chips-label">built with</div>
                <div className="rec-tech-chips-list">
                  {m.techStack.map((t) => (
                    <span key={t} className="rec-skill-chip">{t}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Zone 3 — Sprint strip (3-column) */}
        <div className="rec-sprint-strip">
          <div className="rec-sprint-col">
            <div className="rec-sprint-label">version</div>
            <div className="rec-sprint-val">
              {m.version || m.branch}
            </div>
            <div className="rec-sprint-sub">{m.branch} branch · {m.lastUpdated}</div>
          </div>
          <div className="rec-sprint-col">
            <div className="rec-sprint-label">sprint</div>
            <div className="rec-sprint-tagline-text">{m.tagline}</div>
          </div>
          <div className="rec-sprint-col">
            <div className="rec-sprint-label">project history</div>
            {m.credits && m.credits.length > 0 ? (
              <details className="rec-credits-details">
                <summary>{m.credits.length} contributor{m.credits.length !== 1 ? "s" : ""}</summary>
                <ul className="rec-credits-list">
                  {m.credits.map((c, i) => (
                    <li key={i} className="rec-credits-item">
                      <a href={c.url} target="_blank" rel="noopener noreferrer"
                         className="rec-credits-name">{c.name}</a>
                      <span className="rec-credits-handle">@{c.handle}</span>
                      <span className="rec-credits-role">{c.role}</span>
                    </li>
                  ))}
                </ul>
              </details>
            ) : (
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--faint)" }}>—</span>
            )}
          </div>
        </div>
      </header>

      {/* ══════════════ IMPACT NUMBERS ══════════════ */}
      <div className="rec-impact">
        {(m.impactNumbers || []).map((n, i) => (
          <div key={i} className="rec-impact-tile">
            <div className="rec-impact-num">{n.num}</div>
            <div className="rec-impact-label">{n.label}</div>
            <div className="rec-impact-sub">{n.sub}</div>
          </div>
        ))}
      </div>

      {/* ══════════════ ABOUT ══════════════ */}
      {m.audience && m.audience.length > 0 && (
        <section className="rec-about">
          <h3>Who uses this</h3>
          <div>
            <ul>{m.audience.map((a, i) => <li key={i}>{a}</li>)}</ul>
          </div>
        </section>
      )}

      {/* ══════════════ §01 WHAT WAS ADDED ══════════════ */}
      {m.featuresAdded && m.featuresAdded.length > 0 && (
        <section style={{ marginBottom: 64 }}>
          <div className="rec-section-head">
            <span className="rec-section-num">§ {nextSec()}</span>
            <h2 className="rec-section-title">What was added</h2>
            <div className="rec-section-rule"></div>
            <span className="rec-section-aside">{m.featuresAdded.length} contributions</span>
          </div>
          <div className="rec-features-grid">
            {m.featuresAdded.map((f, i) => (
              <div key={i} className="rec-feature-card">
                <div className="rec-feature-name">{f.name}</div>
                <div className="rec-feature-desc">{f.desc}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ══════════════ §02 HIGHLIGHTS ══════════════ */}
      {highlightCards.length > 0 && (
        <section style={{ marginBottom: 64 }}>
          <div className="rec-section-head">
            <span className="rec-section-num">§ {nextSec()}</span>
            <h2 className="rec-section-title">Selected highlights</h2>
            <div className="rec-section-rule"></div>
            <span className="rec-section-aside">
              {highlightCards.length} of {data.cards.filter((c) => c.status === "shipped").length} shipped
            </span>
          </div>
          <div className="rec-highlights">
            {highlightCards.map((c) => (
              <div key={c.id} className="rec-highlight">
                <div className="rec-highlight-tag">{c.group}</div>
                <h3 className="rec-highlight-title">{c.title}</h3>
                <p className="rec-highlight-blurb">{c.blurb}</p>
                <div className="rec-highlight-foot">
                  {(c.tags || []).slice(0, 3).map((t) => <Pill key={t} kind="tag">{t}</Pill>)}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ══════════════ §03 VIDEO (hidden if empty) ══════════════ */}
      {m.videos && m.videos.length > 0 && (
        <section style={{ marginBottom: 64 }}>
          <div className="rec-section-head">
            <span className="rec-section-num">§ {nextSec()}</span>
            <h2 className="rec-section-title">In action</h2>
            <div className="rec-section-rule"></div>
            <span className="rec-section-aside">{m.videos.length} clips</span>
          </div>
          <div className="rec-video-grid">
            {m.videos.map((v, i) => (
              <div key={i} className="rec-video-card">
                <video src={v.src} poster={v.poster} controls preload="metadata" className="rec-video-el" />
                {v.caption && <div className="rec-video-caption">{v.caption}</div>}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ══════════════ §03/04 TIMELINE ══════════════ */}
      <section style={{ marginBottom: 64 }}>
        <div className="rec-section-head">
          <span className="rec-section-num">§ {nextSec()}</span>
          <h2 className="rec-section-title">Activity timeline</h2>
          <div className="rec-section-rule"></div>
          <span className="rec-section-aside">{shippedMilestones.length} milestones</span>
        </div>
        <div className="rec-timeline">
          <ul className="rec-timeline-list">
            {shippedMilestones.map((mi, i) => (
              <li key={i} className={"rec-timeline-item " + (mi.kind === "in-progress" ? "inprog" : "")}>
                <span className="rec-timeline-date">{mi.date}</span>
                <span className="rec-timeline-dot"></span>
                <span className="rec-timeline-label">{mi.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ══════════════ §04/05 TECH STACK ══════════════ */}
      <section style={{ marginBottom: 64 }}>
        <div className="rec-section-head">
          <span className="rec-section-num">§ {nextSec()}</span>
          <h2 className="rec-section-title">Tech stack</h2>
          <div className="rec-section-rule"></div>
          <span className="rec-section-aside">{(m.techStack || []).length} technologies</span>
        </div>
        <div className="rec-tech">
          {(m.techStack || []).map((t) => (
            <span key={t} className="rec-tech-tag">{t}</span>
          ))}
        </div>
      </section>

      {/* ══════════════ CTA ══════════════ */}
      <div className="rec-cta">
        <div>
          <div className="rec-cta-lead">
            Want the full technical picture — every card, the dependency graph, files heatmap, and the four-step fix plan?
          </div>
          <div className="rec-cta-sub">
            {data.cards.filter((c) => c.status === "shipped").length} shipped features ·{" "}
            {data.files.length} files touched · {data.scripts.rows.length} scripts audited ·{" "}
            {data.sideTasks.length} sibling repos
          </div>
        </div>
        <button className="rec-cta-btn" onClick={onSwitchToDev}>
          Open developer view →
        </button>
      </div>

      <footer className="footer" style={{ marginTop: 56 }}>
        <span>UEVR · luavrlib contribution · Logan Brunet · {m.lastUpdated}</span>
        <span>Built with Claude Code</span>
      </footer>
    </div>
  );
}

window.RecruiterView = RecruiterView;
