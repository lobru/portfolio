# Claude Code · Project Progress Dashboard

A visually dense, public-facing progress dashboard that turns Claude Code's
generated status / changelog / audit markdown into a live, interactive view
of where a project actually stands.

The example dataset is the **UEVR luavrlib branch** — a Lua-API rework with
shipped features, in-progress fixes, open issues, a multi-step fix plan, a
script-compatibility audit, file heatmap, dependency graph, and 3 sibling
side-tasks. Replace it with your own.

## Two views, one toggle

A pill in the top-right corner switches between:

- **Overview** *(default)* — public-facing landing page for recruiters, hiring
  managers, or anyone arriving from LinkedIn or a job application. Big tagline,
  three impact numbers, a curated highlight grid, a clean shipped-only timeline,
  and a tech-stack tag cloud. No jargon firehose.
- **Dev dashboard** — the full dense view with roadmap, kanban, dependency graph,
  open issues + fix plan, file heatmap, audit table, side-tasks, and a Tools
  drawer (see below).

The selected view is persisted in the Tweaks panel, so a shared link to either
view stays put.

## Tools drawer (dev view only)

A floating **Tools** button bottom-left opens a command palette of scriptable
actions that run against the current dataset:

| Tool | Kind | What it does |
|---|---|---|
| **Sync from docs** | AI | Paste new Claude Code markdown; Claude extracts a JSON patch you apply to `data.js` |
| **Generate status report** | AI | 4-sentence stand-up-ready summary of where the project stands |
| **Draft release notes** | AI | Plain-English Markdown release notes grouped by area, ready to paste into a GitHub release |
| **Build script** | scaffold | Downloadable `build.ps1` / `build.sh` tailored to this project's toolchain |
| **Deploy checklist** | scaffold | Markdown checklist derived from open issues + the fix plan |
| **Snapshot data.js** | export | Verbatim dataset dump for archiving point-in-time state |

The AI tools call `window.claude.complete` inline — no API key needed in the
shared artifact. The scaffold tools produce files you run **locally** against
your repo (the browser can't shell out).

## What the dashboard shows

| Section            | What it surfaces                                              |
|--------------------|----------------------------------------------------------------|
| Header + vitals    | Project, branch, last sync, big counters (shipped / open / …) |
| Roadmap            | Date-sorted milestones, color-coded by kind                   |
| Kanban             | Every change as an expandable card across 3 status columns    |
| Dependency map     | SVG DAG showing how features unblock each other               |
| Issues + fix plan  | Active symptoms + numbered acceptance checks                  |
| Files touched      | Heatmap of files changed with per-file change list            |
| Compatibility / Audit table | Any tabular audit Claude Code produced for you        |
| Side-tasks         | Sibling repos / parallel workstreams with verdict breakdowns  |

## Themes

Three palettes are built in (toggle from the Tweaks panel):

- **Console** — dark, geometric, cyan accents. The default.
- **Daylight** — warm paper light theme with italic display type.
- **Phosphor** — green-on-black CRT terminal with scanlines.

Plus toggles for every section, so you can collapse the page down to just
the views your audience cares about.

## File layout

```
index.html         theme tokens + page shell (CSS lives here)
data.js            the dataset — replace this to retarget
dashboard.jsx      view-mode toggle + the dev dashboard sections
recruiter.jsx      the Overview / recruiter-facing layout
depgraph.jsx       SVG dependency graph (dev view)
tools.jsx          Tools drawer (sync / report / release / build / deploy / snapshot)
tweaks-panel.jsx   Tweaks panel scaffold (theme / section toggles)
docs/              your Claude Code progress markdown
CLAUDE.md          update protocol any future Claude session in this project follows
```

## Retargeting to a new project

1. **Drop your Claude Code progress docs** into `docs/`.
2. **Ask Claude to regenerate `data.js`** — `CLAUDE.md` documents the protocol.
3. **Edit `meta` fields in `data.js`** to set your project name, tagline,
   description, audience, highlights, tech stack, and impact numbers — these
   drive the Overview / recruiter view.
4. **(Optional) edit `index.html`** to retitle the page `<title>` and tweak
   the header sigil SVG to your project's mark.
