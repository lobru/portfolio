# Portfolio integration notes

## UEVR luavrlib card — update in Portfolio.html (project e7aab097)

Replace the existing UEVR project-card in Portfolio.html with this snippet.
Key changes: links to the new standalone bundle, updated blurb, updated tags.

```html
<!-- UEVR luavrlib -->
<div class="project-card">
  <div class="project-thumb">
    <div class="project-thumb-placeholder" style="display:flex;flex-direction:column;align-items:center;gap:12px;">
      <svg class="thumb-icon" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 12 L24 6 L42 12 L42 34 L24 42 L6 34 Z" stroke="#56d8ff" stroke-width="2.5" fill="none"/>
        <path d="M15 17 L24 13 L33 17 L33 30 L24 35 L15 30 Z" stroke="#56d8ff" stroke-width="1.5" fill="none" opacity="0.5"/>
        <circle cx="24" cy="24" r="3" fill="#56d8ff"/>
      </svg>
      <span class="project-thumb-label">UEVR · luavrlib</span>
    </div>
    <span class="project-status-bar active">In progress</span>
  </div>
  <div class="project-body">
    <div class="project-eyebrow">C++ · Unreal Engine · Lua · VR Tooling</div>
    <div class="project-title">UEVR · luavrlib</div>
    <div class="project-blurb">
      Contributor to UEVR — the open-source platform that injects VR support into any
      Unreal Engine game. Sprint work on the luavrlib branch: new api_fast namespace
      (3–5× faster actor transforms), multistate Lua workers with a shared map,
      TArray read-path fixes, full GLM rewrite, and a live function-caller UI with
      drag-and-drop — used daily by thousands of VR modders.
    </div>
    <div class="project-tags">
      <span class="project-tag">C++17</span>
      <span class="project-tag">Unreal Engine</span>
      <span class="project-tag">Lua / Sol2</span>
      <span class="project-tag">Dear ImGui</span>
      <span class="project-tag">DirectX 11/12</span>
      <span class="project-tag">24 features shipped</span>
    </div>
  </div>
  <div class="project-foot">
    <span class="project-date">Apr – May 2026</span>
    <a href="UEVR-luavrlib-Dashboard.html" class="project-cta">View dashboard →</a>
  </div>
</div>
```

## File to copy into that project

1. Copy `UEVR Progress Dashboard.html` from this project → rename to
   `UEVR-luavrlib-Dashboard.html` in the portfolio project (e7aab097).
2. The `href` in the card above points to that filename.
3. If hosting on GitHub Pages, put both files in the same folder so the
   relative link resolves.

## GitHub Pages deployment (both projects)

Recommend a single repo structure:
```
lobotomy-x/portfolio/
├── index.html                        ← Portfolio.html renamed
├── UEVR-luavrlib-Dashboard.html      ← this bundle
├── ImGuiColorTextEdit-Dashboard.html ← the other project's bundle
└── media/
    └── screenshots/
        └── textEditor.png
```

Then Settings → Pages → Source: main / root → one URL covers everything.
