# Project: Progress Dashboard

This project renders a single HTML dashboard (`index.html`) that visualizes
the state of a software project from a set of Claude Code-generated docs in
`docs/`. The example dataset is the UEVR luavrlib branch.

## When the user attaches new Claude Code docs

The user will periodically paste or attach new / updated markdown from their
Claude Code sessions — status reports, changelogs, audits, plans, side-task
hand-offs. **Your job is to extract the structured data from those docs and
update `data.js` so the dashboard reflects current reality.**

### Update protocol

1. **Save the docs.** Copy the attached files into `docs/` (or
   `docs/side-tasks/` for hand-off docs). Overwrite the older version if the
   user is replacing a doc; keep the older version alongside if the user is
   adding new ones.

2. **Read the docs carefully.** Look for:
   - Newly shipped features → add to `cards` with `status: "shipped"`
   - Work-in-progress / candidate fixes → `status: "in-progress"`
   - Open issues / symptoms → `symptoms[]` — set `kind: "feature"` for backlog items vs plain bugs
   - Numbered fix plans / next-step lists → `plan[]` — set `state: "done"` on completed steps; use `{label, done}` objects in `checks[]` for individual check completion
   - File-level change lists → `files[]`
   - Audit / compatibility tables → `scripts[]` (or rename if the topic is
     different) — the table is generic, just retitle the section header
   - Side-task / sibling-repo hand-offs → `sideTasks[]`
   - Date-stamped milestones / status-log entries → `milestones[]`
   - New dependency arrows between cards → `edges[]`
   - Screenshots / images → `meta.gallery[]` as `{src: "uploads/img.png", caption: "..."}` — toggle Gallery section on in Tweaks

3. **Update `meta.lastUpdated`** to today's date, and bump `meta.docCount`
   if the doc list changed.

4. **Update the `vitals` numbers** to reflect the new counts. Don't leave
   stale numbers — the header is the first thing the user sees.

5. **Keep the schema documented at the top of `data.js`.** If you introduce
   a new field, add a one-line note there.

6. **Don't touch CSS or component code** unless the user asks. The dashboard
   is fully driven by `data.js` — re-skinning is a separate task.

7. **Verify.** Open `index.html`, screenshot, confirm the new data renders
   without layout breakage, then call `done`.

### When the user asks for trend-tracking

If the user wants to see *how* the project has moved (not just the current
snapshot), suggest adding to `milestones[]` rather than overwriting. The
roadmap timeline is append-only by design — every shipped card should leave
a milestone trail.

### When the user asks for a fresh project / different topic

The dashboard layout is generic. To retarget:
- Swap the entire `PROGRESS_DATA` object
- Edit the header sigil text in `index.html` (lines around the `.sigil` div)
- Edit the page `<title>`

Don't preserve the UEVR-specific names — the user wants the dashboard
shaped to their project, not a renamed clone.

## Tech notes

- React 18 via Babel inline JSX
- Styling: CSS custom properties + three theme palettes (`data-theme` on
  body), no CSS framework
- Tweaks panel handles the host edit-mode protocol; don't reinvent it
- `data.js` exposes `window.PROGRESS_DATA` (the dashboard reads this);
  `window.UEVR_DATA` is kept as a backward-compat alias
