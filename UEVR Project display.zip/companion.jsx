// companion.jsx
// Bridges the dashboard to the local dev machine via a small Python companion
// server running on localhost. Enables: run build/deploy scripts, pipe feature
// comments to the Claude CLI, stream back responses.
//
// Companion server: generate from Tools → "Generate companion server".
// Run with: python companion.py  (no deps beyond stdlib + claude CLI in PATH)
//
// Browser → HTTP localhost note: modern Chrome / Firefox allow HTTPS pages to
// fetch http://localhost:PORT because localhost is a "potentially trustworthy"
// origin. If your browser blocks it, open http://localhost:7373/status once to
// allowlist it.

const { useState: useCState, useEffect: useCEffect, useCallback, useRef } = React;

const COMPANION_LS_KEY = "uevr_companion_config";

const defaultConfig = () => {
  try { return JSON.parse(localStorage.getItem(COMPANION_LS_KEY)) || {}; }
  catch { return {}; }
};

function saveConfig(cfg) {
  try { localStorage.setItem(COMPANION_LS_KEY, JSON.stringify(cfg)); } catch {}
}

// ════════════════════════════════════════════════════════════
// useCompanion — polls localhost, exposes run/askClaude calls
// ════════════════════════════════════════════════════════════
function useCompanion() {
  const saved = defaultConfig();
  const [port,     setPortState] = useCState(saved.port || 7373);
  const [repoPath, setRepoState] = useCState(saved.repoPath || "");
  const [status,   setStatus]    = useCState("disconnected"); // disconnected | connecting | connected | error
  const [info,     setInfo]      = useCState(null);

  const setPort = (v)     => { setPortState(v);     saveConfig({ ...defaultConfig(), port: v }); };
  const setRepoPath = (v) => { setRepoState(v);     saveConfig({ ...defaultConfig(), repoPath: v }); };

  const base = `http://localhost:${port}`;

  const ping = useCallback(async () => {
    try {
      const r = await fetch(`${base}/status`, {
        signal: AbortSignal.timeout(1500),
        headers: { "Accept": "application/json" },
      });
      if (r.ok) {
        const j = await r.json();
        setInfo(j);
        setStatus("connected");
      } else setStatus("error");
    } catch { setStatus("disconnected"); }
  }, [base]);

  useCEffect(() => {
    ping();
    const id = setInterval(ping, 5000);
    return () => clearInterval(id);
  }, [ping]);

  const runScript = useCallback(async (script, type = "auto") => {
    try {
      const r = await fetch(`${base}/run`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ script, type, repoPath }),
        signal: AbortSignal.timeout(180000),
      });
      return await r.json();
    } catch (e) { return { error: String(e.message || e) }; }
  }, [base, repoPath]);

  const askClaude = useCallback(async (prompt) => {
    try {
      const r = await fetch(`${base}/claude`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
        signal: AbortSignal.timeout(120000),
      });
      return await r.json();
    } catch (e) { return { error: String(e.message || e) }; }
  }, [base]);

  return { port, setPort, repoPath, setRepoPath, status, info, runScript, askClaude, ping };
}

// ════════════════════════════════════════════════════════════
// CompanionBanner — shows at top of Tools drawer
// ════════════════════════════════════════════════════════════
function CompanionBanner({ companion }) {
  const { status, info, port, ping } = companion;
  const dotColor =
    status === "connected"     ? "var(--shipped)"
    : status === "connecting"  ? "var(--inprog)"
    : "var(--faint)";
  const label =
    status === "connected"
      ? `● Connected · localhost:${port} · cwd: ${info?.cwd || "?"}`
      : `○ Companion not running · localhost:${port}`;
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "10px 14px", marginBottom: 12,
      background: "var(--bg)",
      border: "1px solid var(--line)",
      borderRadius: "var(--radius-s)",
      fontFamily: "var(--font-mono)", fontSize: 11,
    }}>
      <span style={{ color: status === "connected" ? "var(--shipped)" : "var(--muted)" }}>{label}</span>
      <button
        onClick={ping}
        style={{
          fontFamily: "var(--font-mono)", fontSize: 10, textTransform: "uppercase",
          letterSpacing: "0.1em", color: "var(--muted)",
          border: "1px solid var(--line)", borderRadius: 3,
          padding: "4px 8px", cursor: "pointer",
        }}>retry</button>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// AskClaudeBar — mounts inside an expanded Card
// ════════════════════════════════════════════════════════════
function AskClaudeBar({ card, companion }) {
  const [open,   setOpen]   = useCState(false);
  const [text,   setText]   = useCState("");
  const [status, setStatus] = useCState("idle"); // idle | working | ok | err
  const [reply,  setReply]  = useCState("");
  const connected = companion?.status === "connected";

  const buildPrompt = () => {
    const parts = [
      `You are reviewing a code change in the UEVR ${window.PROGRESS_DATA?.meta?.branch || ""} branch.`,
      "",
      `Feature: ${card.title}`,
      `Group: ${card.group}`,
      `Status: ${card.status}`,
      `Description: ${card.blurb}`,
    ];
    if (card.detail) parts.push("", "Detail:", card.detail);
    if (card.files?.length) parts.push("", "Files: " + card.files.join(", "));
    if (card.surface?.length) parts.push("", "API surface:", ...card.surface.map(s => "  • " + s));
    parts.push("", "Developer comment:", text);
    return parts.join("\n");
  };

  const onSend = async () => {
    if (!text.trim()) return;
    if (connected) {
      setStatus("working"); setReply("");
      const res = await companion.askClaude(buildPrompt());
      if (res.error) { setReply(res.error); setStatus("err"); }
      else { setReply(res.output); setStatus("ok"); }
    } else {
      // Fallback: copy rich prompt to clipboard
      await navigator.clipboard.writeText(buildPrompt()).catch(() => {});
      setReply("Companion not connected — prompt copied to clipboard. Paste into your Claude CLI session.");
      setStatus("ok");
    }
  };

  return (
    <div className="card-section" style={{ marginTop: 12 }}>
      {!open ? (
        <button
          className="tool-btn"
          style={{ width: "100%", justifyContent: "center", display: "flex", gap: 8, alignItems: "center" }}
          onClick={() => setOpen(true)}
        >
          <span style={{ color: connected ? "var(--shipped)" : "var(--muted)" }}>
            {connected ? "●" : "○"}
          </span>
          {connected ? "Ask Claude CLI about this feature" : "Ask Claude (clipboard fallback — companion not running)"}
        </button>
      ) : (
        <div style={{
          border: "1px solid var(--line)", borderRadius: "var(--radius-s)",
          background: "var(--bg)", padding: 12,
          display: "flex", flexDirection: "column", gap: 8,
        }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.1em" }}>
            {connected ? `→ Claude CLI · localhost:${companion.port}` : "→ Clipboard (companion offline)"}
          </div>
          <textarea
            style={{
              width: "100%", minHeight: 80,
              background: "var(--panel)", color: "var(--text)",
              border: "1px solid var(--line)", borderRadius: 3,
              padding: "8px 10px", fontFamily: "var(--font-mono)", fontSize: 12,
              lineHeight: 1.4, resize: "vertical",
            }}
            placeholder="e.g. 'What are the thread-safety risks of this? What should I test?'"
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) onSend(); }}
          />
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button className="tool-btn primary" onClick={onSend} disabled={!text.trim() || status === "working"}>
              {status === "working" ? "Asking…" : connected ? "→ Send to Claude" : "Copy prompt"}
            </button>
            <button className="tool-btn" onClick={() => { setOpen(false); setText(""); setReply(""); setStatus("idle"); }}>Cancel</button>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)" }}>⌘↵ to send</span>
          </div>
          {reply && (
            <div style={{
              background: "var(--panel)", border: "1px solid var(--line)", borderRadius: 3,
              padding: 10, fontFamily: "var(--font-mono)", fontSize: 11.5, lineHeight: 1.5,
              color: status === "err" ? "var(--open)" : "var(--text)",
              maxHeight: 260, overflowY: "auto", whiteSpace: "pre-wrap",
            }}>
              {reply}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// Companion Python server source
// ════════════════════════════════════════════════════════════
function generateCompanionPy(port = 7373) {
  return `#!/usr/bin/env python3
"""companion.py — Progress Dashboard local companion server.
Bridges the dashboard (running in your browser) to your local machine.

Features:
  • POST /run     — execute a build/deploy script (PowerShell on Windows, bash elsewhere)
  • POST /claude  — run \`claude -p "prompt"\` and return the output
  • GET  /status  — health-check used by the dashboard to detect the companion

Usage:
  python companion.py [--port ${port}] [--claude-cli claude]

Requirements:
  • Python 3.9+ (stdlib only — no pip installs)
  • Claude CLI in PATH  (https://claude.ai/download → CLI tab)
    OR set CLAUDE_CLI env var to the full path

CORS note: serves Access-Control-Allow-Private-Network: true so Chrome can
connect from an HTTPS dashboard page.
"""

import http.server, json, os, subprocess, sys, tempfile, argparse

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, default=${port})
    p.add_argument("--claude-cli", default=os.environ.get("CLAUDE_CLI", "claude"))
    return p.parse_args()

ARGS = parse_args()

class Handler(http.server.BaseHTTPRequestHandler):
    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.end_headers()

    def do_GET(self):
        self.send_response(200)
        self.cors()
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        if self.path.startswith("/status"):
            self.wfile.write(json.dumps({
                "connected": True,
                "port": ARGS.port,
                "cwd": os.getcwd(),
                "platform": sys.platform,
                "claude_cli": ARGS.claude_cli,
            }).encode())
        else:
            self.wfile.write(json.dumps({"error": "not found"}).encode())

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n)) if n else {}

        if self.path == "/run":
            result = self._run_script(body)
        elif self.path == "/claude":
            result = self._run_claude(body)
        else:
            result = {"error": "unknown endpoint"}

        data = json.dumps(result).encode()
        self.send_response(200)
        self.cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _run_script(self, body):
        script = body.get("script", "")
        repo   = body.get("repoPath", "")
        cwd    = repo if repo and os.path.isdir(repo) else os.getcwd()
        ext    = ".ps1" if sys.platform == "win32" else ".sh"
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False, mode="w") as f:
            f.write(script); fname = f.name
        try:
            if sys.platform == "win32":
                cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", fname]
            else:
                os.chmod(fname, 0o755)
                cmd = ["bash", fname]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=300, cwd=cwd)
            return {"stdout": r.stdout, "stderr": r.stderr, "returncode": r.returncode}
        except subprocess.TimeoutExpired:
            return {"error": "timeout after 300s"}
        except Exception as e:
            return {"error": str(e)}
        finally:
            try: os.unlink(fname)
            except: pass

    def _run_claude(self, body):
        prompt = body.get("prompt", "")
        try:
            r = subprocess.run(
                [ARGS.claude_cli, "-p", prompt, "--no-streaming"],
                capture_output=True, text=True, timeout=120,
            )
            return {"output": r.stdout or r.stderr, "returncode": r.returncode}
        except FileNotFoundError:
            return {"error": f"Claude CLI not found at '{ARGS.claude_cli}'. Install from https://claude.ai/download or set CLAUDE_CLI env var."}
        except subprocess.TimeoutExpired:
            return {"error": "Claude CLI timed out after 120s"}
        except Exception as e:
            return {"error": str(e)}

    def log_message(self, fmt, *args):
        print(f"[companion] {fmt % args}")

if __name__ == "__main__":
    srv = http.server.HTTPServer(("localhost", ARGS.port), Handler)
    print(f"[companion] Listening on http://localhost:{ARGS.port}")
    print(f"[companion] CWD: {os.getcwd()}")
    print(f"[companion] Claude CLI: {ARGS.claude_cli}")
    print(f"[companion] Press Ctrl+C to stop.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\\n[companion] Stopped.")
`;
}

window.useCompanion        = useCompanion;
window.CompanionBanner     = CompanionBanner;
window.AskClaudeBar        = AskClaudeBar;
window.generateCompanionPy = generateCompanionPy;

// ════════════════════════════════════════════════════════════
// useNotes — per-card notes persisted to localStorage
// ════════════════════════════════════════════════════════════
function useNotes(cardId) {
  const key = "note_" + cardId;
  const [text, setText] = useCState(() => {
    try { return localStorage.getItem(key) || ""; } catch { return ""; }
  });
  const save = useCallback((val) => {
    setText(val);
    try {
      if (val) localStorage.setItem(key, val);
      else localStorage.removeItem(key);
    } catch {}
  }, [key]);
  return [text, save];
}

function getAllNotes() {
  const out = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("note_")) {
        const val = localStorage.getItem(k);
        if (val && val.trim()) out[k.slice(5)] = val;
      }
    }
  } catch {}
  return out;
}

function CopyPackBtn({ card, notes, data }) {
  const [copied, setCopied] = useCState(false);
  const onClick = async () => {
    const md = buildContextPack(card, notes, data);
    try {
      await navigator.clipboard.writeText(md);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback: create a temp textarea and copy from it
      const ta = document.createElement("textarea");
      ta.value = md;
      ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  return (
    <button
      onClick={onClick}
      style={{
        fontFamily: "var(--font-mono)", fontSize: 10, textTransform: "uppercase",
        letterSpacing: "0.1em",
        color: copied ? "var(--shipped)" : "var(--muted)",
        border: "1px solid var(--line)", padding: "4px 10px",
        borderRadius: 3, cursor: "pointer",
        transition: "color .2s",
      }}>
      {copied ? "✓ Copied!" : "Copy to clipboard"}
    </button>
  );
}

// ════════════════════════════════════════════════════════════
// NotesArea — textarea + export button, lives inside Card
// ════════════════════════════════════════════════════════════
function NotesArea({ card, data }) {
  const [notes, setNotes] = useNotes(card.id);
  const [saved,  setSaved] = useCState(false);
  const timerRef = useRef(null);

  const onChange = (e) => {
    const val = e.target.value;
    setNotes(val);
    setSaved(false);
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setSaved(true), 800);
  };

  const exportPack = () => {
    const md = buildContextPack(card, notes, data);
    const blob = new Blob([md], { type: "text/markdown" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url;
    a.download = `context-${card.id}.md`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="card-section" style={{ marginTop: 12 }}>
      <div style={{
        display: "flex", alignItems: "center",
        justifyContent: "space-between", marginBottom: 6,
      }}>
        <div className="card-section-label">
          Notes
          {notes && <span style={{ color: saved ? "var(--shipped)" : "var(--muted)", marginLeft: 8 }}>
            {saved ? "✓ saved" : "…"}
          </span>}
        </div>
        {notes.trim() && (
          <div style={{ display: "flex", gap: 6 }}>
            <button
              onClick={exportPack}
              style={{
                fontFamily: "var(--font-mono)", fontSize: 10, textTransform: "uppercase",
                letterSpacing: "0.1em", color: "var(--accent)",
                border: "1px solid var(--line)", padding: "4px 10px",
                borderRadius: 3, cursor: "pointer",
              }}>
              Export .md ↓
            </button>
            <CopyPackBtn card={card} notes={notes} data={data} />
          </div>
        )}
      </div>
      <textarea
        value={notes}
        onChange={onChange}
        placeholder="Add notes, observations, hypotheses, or questions about this issue. Hit 'Export context pack' to generate a handoff doc for a new Claude session."
        style={{
          width: "100%", minHeight: 96,
          background: "var(--bg)", color: "var(--text)",
          border: "1px solid var(--line)", borderRadius: 3,
          padding: "10px 12px",
          fontFamily: "var(--font-mono)", fontSize: 12, lineHeight: 1.5,
          resize: "vertical",
        }}
      />
      {!notes.trim() && (
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--faint)", marginTop: 4 }}>
          Notes auto-save to localStorage · no AI connection required
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// buildContextPack — generates the markdown handoff file
// ════════════════════════════════════════════════════════════
function buildContextPack(card, notes, data) {
  const meta = data?.meta || {};
  const edges = data?.edges || [];
  const cards = data?.cards || [];
  const plan  = data?.plan  || [];

  // Find related cards via edges
  const relatedIds = new Set();
  edges.forEach(e => {
    if (e.from === card.id) relatedIds.add(e.to);
    if (e.to   === card.id) relatedIds.add(e.from);
  });
  const relatedCards = cards.filter(c => relatedIds.has(c.id));

  // Find plan steps that mention this card
  const relatedPlan = plan.filter(p => p.cardId === card.id || (card.id && p.title?.toLowerCase().includes(card.id)));

  const lines = [];
  lines.push(`# Context pack — ${card.title}`);
  lines.push(`_Generated ${new Date().toISOString().slice(0,10)} · ${meta.project || "Project"} · ${meta.branch || ""}_`);
  lines.push("");
  lines.push("---");
  lines.push("");

  // Issue summary
  lines.push("## Issue");
  lines.push(`**${card.title}**`);
  lines.push("");
  lines.push(`| Field | Value |`);
  lines.push(`|---|---|`);
  lines.push(`| Group | ${card.group || "—"} |`);
  lines.push(`| Status | ${card.status} |`);
  if (card.tags?.length) lines.push(`| Tags | ${card.tags.join(", ")} |`);
  lines.push("");
  lines.push(card.blurb || "");
  if (card.detail) { lines.push(""); lines.push(card.detail); }
  if (card.fix)    { lines.push(""); lines.push(`**Fix:** ${card.fix}`); }

  // Surface / API list
  if (card.surface?.length) {
    lines.push(""); lines.push("### API surface");
    card.surface.forEach(s => lines.push(`- ${s}`));
  }

  // Files
  if (card.files?.length) {
    lines.push(""); lines.push("### Files involved");
    card.files.forEach(f => lines.push(`- \`${f}\``));
  }

  // Project context
  lines.push("");
  lines.push("---");
  lines.push("");
  lines.push("## Project context");
  lines.push(`- **Project:** ${meta.project || "—"} · ${meta.branch || ""} branch`);
  lines.push(`- **Baseline:** ${meta.baseline || "—"}`);
  lines.push(`- **Last updated:** ${meta.lastUpdated || "—"}`);
  if (meta.repoPath) lines.push(`- **Repo:** ${meta.repoPath}`);

  // Related features
  if (relatedCards.length) {
    lines.push("");
    lines.push("## Related features (dependency graph)");
    relatedCards.forEach(c => {
      lines.push(`- **${c.title}** _(${c.status}, ${c.group})_ — ${c.blurb || ""}`);
      if (c.files?.length) lines.push(`  Files: ${c.files.join(", ")}`);
    });
  }

  // Plan steps
  if (plan.length || relatedPlan.length) {
    lines.push("");
    lines.push("## Fix plan");
    (relatedPlan.length ? relatedPlan : plan).forEach(p => {
      lines.push(`### §${p.step} — ${p.title} _(${p.state || "pending"})_`);
      if (p.detail) lines.push(p.detail);
      if (p.checks?.length) {
        lines.push("");
        p.checks.forEach(c => {
          const label = typeof c === "object" ? c.label : c;
          const done  = typeof c === "object" ? c.done  : false;
          lines.push(`- [${done ? "x" : " "}] ${label}`);
        });
      }
      lines.push("");
    });
  }

  // Developer notes
  lines.push("---");
  lines.push("");
  lines.push("## Developer notes");
  lines.push(notes.trim() || "_No notes added._");

  // Handoff prompt
  lines.push("");
  lines.push("---");
  lines.push("");
  lines.push("## Handoff prompt");
  lines.push("> Paste this entire document into a new Claude session. Context above is pre-loaded.");
  lines.push("");
  lines.push("```");
  lines.push(`You are picking up work on the ${meta.project || "project"} (${meta.branch || ""} branch).`);
  lines.push("");
  lines.push(`The issue is: **${card.title}**`);
  lines.push(`Severity / kind: ${card.tags?.join(", ") || card.status}`);
  lines.push("");
  if (notes.trim()) {
    lines.push("Developer context / question:");
    lines.push(notes.trim());
    lines.push("");
  }
  lines.push("All relevant context is in the sections above. Please:");
  lines.push("1. Summarise what you understand the root cause to be");
  lines.push("2. Propose the most targeted fix, referencing the files listed");
  lines.push("3. List any clarifying questions you have before proceeding");
  lines.push("```");

  return lines.join("\n");
}

window.useNotes        = useNotes;
window.getAllNotes     = getAllNotes;
window.NotesArea       = NotesArea;
window.buildContextPack = buildContextPack;

// ════════════════════════════════════════════════════════════
// useChecklist — per-checklist checked states in localStorage
// ════════════════════════════════════════════════════════════
function useChecklist(ownerId, count) {
  const key = "chk_" + ownerId;
  const [states, setStates] = useCState(() => {
    try {
      const raw = localStorage.getItem(key);
      const arr = raw ? JSON.parse(raw) : [];
      // Pad / trim to match current item count
      return Array.from({ length: count }, (_, i) => arr[i] || false);
    } catch { return Array(count).fill(false); }
  });

  const toggle = useCallback((i) => {
    setStates(prev => {
      const next = [...prev];
      next[i] = !next[i];
      try { localStorage.setItem(key, JSON.stringify(next)); } catch {}
      return next;
    });
  }, [key]);

  const reset = useCallback(() => {
    const next = Array(count).fill(false);
    setStates(next);
    try { localStorage.removeItem(key); } catch {}
  }, [key, count]);

  const doneCount = states.filter(Boolean).length;
  return { states, toggle, reset, doneCount, total: count };
}

// ════════════════════════════════════════════════════════════
// CheckList — interactive checkboxes with progress + export
// ════════════════════════════════════════════════════════════
function CheckList({ ownerId, ownerTitle, items, showExport = true }) {
  const normalized = items.map(item =>
    typeof item === "object" ? item : { label: item, done: false }
  );
  // Seed from static done flags if present
  const seedDone = normalized.map(i => i.done || false);
  const { states, toggle, reset, doneCount, total } = useChecklist(ownerId, normalized.length);
  // Merge static done with interactive states (interactive wins)
  const effective = states.map((s, i) => s || seedDone[i]);
  const [copied, setCopied] = useCState(false);

  const buildMd = () => {
    const lines = [
      `# Checklist — ${ownerTitle}`,
      `_Progress: ${doneCount}/${total}_`,
      "",
    ];
    normalized.forEach((item, i) => {
      lines.push(`- [${effective[i] ? "x" : " "}] ${item.label}`);
    });
    return lines.join("\n");
  };

  const onCopy = async () => {
    try { await navigator.clipboard.writeText(buildMd()); }
    catch { /* silent fallback */ }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const onExport = () => {
    const blob = new Blob([buildMd()], { type: "text/markdown" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url;
    a.download = `checklist-${ownerId}.md`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };

  const pct = total > 0 ? (doneCount / total) * 100 : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
      {/* Progress bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <div style={{ flex: 1, height: 4, background: "var(--bg)", borderRadius: 2, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: pct === 100 ? "var(--shipped)" : "var(--accent)", borderRadius: 2, transition: "width .3s" }} />
        </div>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: pct === 100 ? "var(--shipped)" : "var(--muted)", minWidth: 40, textAlign: "right" }}>
          {doneCount}/{total}
        </span>
      </div>

      {/* Items */}
      <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 4 }}>
        {normalized.map((item, i) => (
          <li
            key={i}
            onClick={() => toggle(i)}
            style={{
              display: "flex", alignItems: "flex-start", gap: 10,
              cursor: "pointer", padding: "5px 0",
              fontFamily: "var(--font-mono)", fontSize: 12,
              color: effective[i] ? "var(--muted)" : "var(--text-2)",
              textDecoration: effective[i] ? "line-through" : "none",
              transition: "color .15s",
              userSelect: "none",
            }}
          >
            {/* Checkbox */}
            <span style={{
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              width: 14, height: 14, border: `1.5px solid ${effective[i] ? "var(--shipped)" : "var(--muted)"}`,
              borderRadius: 2, flexShrink: 0, marginTop: 2,
              background: effective[i] ? "var(--shipped)" : "transparent",
              transition: "all .15s",
            }}>
              {effective[i] && (
                <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
                  <path d="M1 3L3.5 5.5L8 1" stroke="var(--bg)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </span>
            {item.label}
          </li>
        ))}
      </ul>

      {/* Actions */}
      {showExport && (
        <div style={{ display: "flex", gap: 6, marginTop: 10, paddingTop: 10, borderTop: "1px dashed var(--line)" }}>
          <button className="tool-btn" style={{ fontSize: 10 }} onClick={onCopy}>
            {copied ? "✓ Copied!" : "Copy checklist"}
          </button>
          <button className="tool-btn" style={{ fontSize: 10 }} onClick={onExport}>Export .md</button>
          {doneCount > 0 && (
            <button className="tool-btn" style={{ fontSize: 10, color: "var(--open)" }} onClick={reset}>Reset</button>
          )}
        </div>
      )}
    </div>
  );
}

window.CheckList = CheckList;
window.useChecklist = useChecklist;
